/*
 LICENSE INFORMATION:
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License (LGPL) as published by the Free Software Foundation.
 
 Please refer to the COPYING file for more information.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 
 Copyright (c) 2010 Peter Persson (pep.fishmoose@gmail.com)
 */

#ifndef _ACATE_H_
#define _ACATE_H_

#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
	
	
	/**
	 * Public terminal instance structure
	 */
	typedef struct Terminal_
	{	
		/**
		 * @name terminal properties
		 */
		
		/*@{*/
		uint16_t		cols;			/**< terminal columns (read only) */
		uint16_t		rows;			/**< terminal lines (read only) */
		/*@}*/
		
		/**
		 * @name terminal screen representation
		 */
		
		/*@{*/
		uint16_t		**cells;		/**< terminal screen image (read only) */
		uint8_t			*linemode;		/**< line mode for each line (read only) */
		bool			*line_dirty;	/**< indicates (read/write) */
		/*@}*/
		
		/**
		 * @name terminal scrollback log
		 */
		
		/*@{*/
		uint16_t		**log;			/**< scrollback image (read only) */
		uint16_t		logmax;			/**< max. no of lines in log buffer (read only) */
		uint16_t		logpos;			/**< current log position (read only) */
		uint16_t		logsiz;			/**< number of valid lines in the log (read only) */
		bool			logchanged;		/**< true if the log has been updated (read/write) */
		/*@}*/
		
		/**
		 * @name mouse cursor state
		 */
		
		/*@{*/
		bool			mousepos_dirty;	/**< (read/write) - not implemented */
		uint16_t		mouse_mode;		/**< (read only) */
		uint16_t		mouse_col;		/**< mouse cursor column (read only)*/
		uint16_t		mouse_row;		/**< mouse cursor row (read only)*/
		/*@}*/
		
		/**
		 * @name character cursor state
		 */
		
		/*@{*/
		bool			curpos_dirty;	/**< (read/write) */
		bool			curs_mode;		/**< cursor enabled/disabled (read only) */
		int16_t			row;			/**< cursor row (read only) */
		int16_t			col;			/**< cursor column (read only) */
		/*@}*/
		
		/**
		 * @name callbacks
		 */
		
		/*@{*/
		void			(*callback_bell)(void*);						/**< handler for bell sound */
		void			(*callback_osc)(void*, uint8_t*);				/**< handler for operating system commands */
		void			(*callback_write)(void*, uint8_t*, size_t);		/**< handler that writes data to the terminal input */
		
		void*			parent_ref;	/**< user-specific reference used to identify the parent resource */
		/*@}*/
		
	} Terminal;
	
	/**
	 * Injects data into a terminal
	 *
	 * The function injects data into the terminal.
	 * 
	 * @param rt			Pointer to terminal instace resource.
	 * @param data			Pointer to data.
	 * @param len			Number of bytes.
	 */
	extern void			acate_inject(Terminal *rt, uint8_t *data, size_t len);
	
	/**
	 * Report mouse event
	 *
	 * The function reports a mouse event to a terminal.
	 * 
	 * @param rt			Pointer to terminal instace resource.
	 * @param buttons		Buttons
	 * @param x				Mouse x-coordinate (column)
	 * @param y				Mouse y-coordinate (row)
	 */
	extern void			acate_mouse(Terminal* rt, uint16_t buttons, uint16_t x, uint16_t y);
	
	/**
	 * Report mouse event
	 *
	 * The function reports a keyboard event to a terminal.
	 * 
	 * @param rt			Pointer to terminal instace resource.
	 * @param keycode		Character
	 * @param mode			Meta keys
	 */
	extern void			acate_key(Terminal* rt, uint16_t keycode, uint16_t mode);
	
	/**
	 * Send data to terminal
	 *
	 * The function sends a block of data to the terminal.
	 * 
	 * @param rt			Pointer to terminal instace resource.
	 * @param data			Pointer to data.
	 * @param len			Number of bytes.
	 */
	extern void			acate_send(Terminal *rt, uint8_t* data, size_t len);
	
	/**
	 * Creates a terminal instance
	 *
	 * Function allocates the resources needed for a terminal instance with the specified properties,
	 * and returns a pointer which shall be used for future reference of that terminal instance.
	 *
	 * @param rows		Number of rows
	 * @param cols		Number of columns
	 * @param buffer	Number of lines that shall be buffered by the terminal (scrollback)
	 * @param fg		Default foreground colour (0-15)
	 * @param bg		Default background colour (0-15)
	 * @param encoding	Pointer to an array of four character encoding tables
	 * @return			Pointer used to reference the terminal instance
	 */
	extern Terminal*	acate_create(uint16_t rows, uint16_t cols, uint16_t buffer, uint16_t fg, uint16_t bg, uint8_t** encoding);
	
	/**
	 * Destroys a terminal instance
	 *
	 * The function frees all resources allocated by a terminal instance.
	 * 
	 * @param rt		Pointer to terminal instace resource.
	 */
	extern void			acate_destroy(Terminal *rt);
	
	/**
	 * Migrate a terminal state from one resource to another
	 *
	 * The function copies the current state and display contents from one terminal
	 * resource to another. The source and destination can be of different sizes.
	 * Note that the destination resource will be overwritten/replaced.
	 *
	 * @param dst		Destination terminal resource. Will be overwritten.
	 * @param src		Source terminal resource.
	 * @return			True if terminal can be resized, otherwise false
	 */		
	extern void			acate_migrate(Terminal* dst, Terminal* src);

	/**
	 * Test terminal resize capability
	 *
	 * The function checks wether or not it's possible to resize the terminal using acate_resize().
	 * 
	 * @param rt		Pointer to terminal instance resource.
	 * @param rows		Number of rows
	 * @param cols		Number of columns
	 * @return			True if terminal can be resized, otherwise false
	 */	
	extern bool			acate_can_resize(Terminal* rt, uint16_t rows, uint16_t cols);

	/**
	 * Resize existing terminal.
	 *
	 * The function attempts to resize a terminal without re-allocation.
	 * 
	 * @param rt		Pointer to terminal instance resource.
	 * @param rows		Number of rows
	 * @param cols		Number of columns
	 * @return			True if successful, otherwise false.
	 */	
	extern bool			acate_resize(Terminal* rt, uint16_t rows, uint16_t cols);

	/**
	 * Clean up and shrink memory
	 *
	 * The function attempts to reduce memory usage.
	 * 
	 * @param rt		Pointer to terminal instance resource.
	 */		
	extern void			acate_cleanup(Terminal* rt);

	/**
	 * Output information about a terminal resource (internal debugging)
	 *
	 * The function outputs information about a terminal resource in readable text form.
	 *
	 * Note that this function is just used for internal debugging and should not be used by
	 * client applications. It may very well disappear (an re-appear) between Acate versions.
	 *
	 * @param rt		Pointer to terminal instance resource.
	 */		
	extern void acate_to_string(Terminal* rt);

#ifdef __cplusplus
}
#endif /* __cplusplus */


/**
 * Keyboard modes
 */
#define AC_KEYMODE_NORMAL		0
#define	AC_KEYMODE_SHIFTED		1
#define	AC_KEYMODE_ALT			2
#define AC_KEYMODE_CONTROL		3

/**
 * Keyboard codes
 */
#define AC_NORMAL_KEYS		0x0000
#define	AC_FUNCTION_KEYS	0x1000
#define	AC_SPECIAL_KEYS		0x1100
#define	AC_CURSOR_KEYS		0x1200
#define	AC_KEYPAD_KEYS		0x1300

#define AC_FUNCTION_F(x)	(AC_FUNCTION_KEYS | (x - 1))

#define AC_SPECIAL_DELETE	(AC_SPECIAL_KEYS | 0x00)
#define AC_SPECIAL_INSERT	(AC_SPECIAL_KEYS | 0x01)
#define AC_SPECIAL_HOME		(AC_SPECIAL_KEYS | 0x02)
#define AC_SPECIAL_PAGE_UP	(AC_SPECIAL_KEYS | 0x03)
#define AC_SPECIAL_PAGE_DOWN	(AC_SPECIAL_KEYS | 0x04)

#define AC_CURSOR_UP		(AC_CURSOR_KEYS | 0x00)
#define AC_CURSOR_DOWN		(AC_CURSOR_KEYS | 0x01)
#define AC_CURSOR_RIGHT		(AC_CURSOR_KEYS | 0x02)
#define AC_CURSOR_LEFT		(AC_CURSOR_KEYS | 0x03)

#define AC_KEYPAD_N(x)		(AC_KEYPAD_KEYS | x)
#define AC_KEYPAD_DIV		(AC_KEYPAD_KEYS | 0x0a)
#define AC_KEYPAD_MUL		(AC_KEYPAD_KEYS | 0x0b)
#define AC_KEYPAD_SUB		(AC_KEYPAD_KEYS | 0x0c)
#define AC_KEYPAD_ADD		(AC_KEYPAD_KEYS | 0x0d)
#define AC_KEYPAD_DEC		(AC_KEYPAD_KEYS | 0x0e)
#define AC_KEYPAD_ENTER		(AC_KEYPAD_KEYS | 0x0f)

#endif /* _ACATE_H_ */

