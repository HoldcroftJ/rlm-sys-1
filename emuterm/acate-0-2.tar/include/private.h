/*
 LICENSE INFORMATION:
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License (LGPL) as published by the Free Software Foundation.
 
 Please refer to the COPYING file for more information.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 
 Copyright (c) 2010 Peter Persson (pep.fishmoose@gmail.com)
 */

#ifndef _PRIVATE_H_
#define _PRIVATE_H_

#define BUF_SIZE 200

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "acate.h"

#include <sys/types.h>

typedef struct attribute
{
	uint16_t		attr;
	uint8_t			latched_char;
	
	bool			full;
	bool			half;
	bool			italics;
	bool			underline;
	bool			blink;
	bool			reverse;
	
	uint16_t		bg;
	uint16_t		fg;
	
	uint16_t		current_g;
	uint8_t*		charset_g[2];
	
} ATTRIBUTE;

typedef struct TermInternal_
{
	Terminal publ;
	struct state_entry*	state;		/* pointer to current state structure */
	
	uint32_t		bufsize;		/* terminal buffer size */
	uint8_t			*buffer;		/* terminal buffer */
	
	uint8_t			**char_lookup; /* character encoding tables */

	/* scroll region */
	uint16_t		top;
	uint16_t		bottom;
	
	/* horizontal tab image */
	uint8_t*		tabs;
	
	/* global terminal properties */
	bool			keymode;
	bool			vt52;		/* if true, terminal is in vt52 mode */
	bool			col132;
	bool			scroll;
	bool			reverse;
	bool			origin;
	bool			wrap;
	bool			repeat;
	
	bool			disp_ctrl;
	bool			insert;
	bool			lf_mode;
		
	/* attribute settings */
	struct			attribute cur;
	struct			attribute saved;
	struct			attribute def;

	/* saved cursor */
	uint16_t		saved_col;
	uint16_t		saved_row;

	/* misc. buffers */
	uint16_t		osc_position;
	uint8_t			osc_buffer[BUF_SIZE];
	
	uint8_t			collect_buffer[BUF_SIZE];
	
	uint16_t		param_position;
	uint16_t		param_buffer[BUF_SIZE];
	
} TermInternal;

typedef struct state_entry
{
	struct state_entry *next;
	void	(*action)(TermInternal*, uint8_t);
} STATE_ENTRY;


#endif /* _PRIVATE_H_ */

