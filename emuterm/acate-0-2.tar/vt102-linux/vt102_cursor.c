static void vt102_curs_save_attr(TermInternal *ti, uint8_t ignore)
{
	memcpy(&ti->saved, &ti->cur, sizeof(struct attribute));
}

static void vt102_curs_restore_attr(TermInternal *ti, uint8_t ignore)
{
	memcpy(&ti->cur, &ti->saved, sizeof(struct attribute));
}


static void vt102_curs_save(TermInternal *ti, uint8_t ignore)
{
	ti->saved_col = ti->publ.col;
	ti->saved_row = ti->publ.row;
}

static void vt102_curs_restore(TermInternal *ti, uint8_t ignore)
{
	ti->publ.col = ti->saved_col;
	ti->publ.row = ti->saved_row;
}

static void vt102_curs_fwd(TermInternal *ti, uint8_t ignore)
{
}

static void vt102_curs_back(TermInternal *ti, uint8_t ignore)
{
}

static void vt102_curs_index(TermInternal *ti, uint8_t ignore)
{	
	if(ti->publ.row == ti->bottom)
		prim_scroll_up(ti, ti->top, ti->bottom);
	else if(ti->publ.row < ti->publ.rows)
		ti->publ.row++;

}

static void vt102_curs_index_rev(TermInternal *ti, uint8_t ignore)
{
	if(ti->publ.row == ti->top)
		prim_scroll_down(ti, ti->top, ti->bottom);
	else if(ti->publ.row > 0)
		ti->publ.row--;
}

static void vt102_curs_up(TermInternal *ti, uint8_t ignore)
{
	ti->publ.row -= ti->param_buffer[0] ? ti->param_buffer[0]  : 1;

	if(ti->publ.row < ti->top)
		ti->publ.row = ti->top;
}

static void vt102_curs_down(TermInternal *ti, uint8_t ignore)
{
	ti->publ.row += ti->param_buffer[0] ? ti->param_buffer[0]  : 1;	

	if(ti->publ.row > ti->bottom)
		ti->publ.row = ti->bottom;
}

static void vt102_curs_left(TermInternal *ti, uint8_t ignore)
{
	ti->publ.col -= ti->param_buffer[0] ? ti->param_buffer[0]  : 1;
	
	if(ti->publ.col < 0)
		ti->publ.col = 0;
}

static void vt102_curs_right(TermInternal *ti, uint8_t ignore)
{
	ti->publ.col += ti->param_buffer[0] ? ti->param_buffer[0]  : 1;

	if(ti->publ.col >= (ti->publ.cols - 1))
		ti->publ.col = ti->publ.cols - 1;
}

static void vt102_curs_column_absolute(TermInternal *ti, uint8_t ignore)
{
	ti->publ.col = ti->param_buffer[0] - 1;
	
	if(ti->publ.col < 0)
		ti->publ.col = 0;
	else if(ti->publ.col > (ti->publ.cols - 1))
		ti->publ.col = ti->publ.cols - 1;
}


static void vt102_curs_column(TermInternal *ti, uint8_t ignore)
{
	ti->publ.col = ti->param_buffer[0] - 1;
	
	if(ti->publ.col < 0)
		ti->publ.col = 0;
	else if(ti->publ.col > (ti->publ.cols - 1))
		ti->publ.col = ti->publ.cols - 1;
}

static void vt102_curs_line_absolute(TermInternal *ti, uint8_t ignore)
{	
	ti->publ.row = ti->param_buffer[0] - 1;
	
	if(ti->publ.row < 0)
		ti->publ.row = 0;
	if(ti->publ.row > (ti->publ.rows - 1))
		ti->publ.row = ti->publ.rows - 1;
}

static void vt102_curs_line(TermInternal *ti, uint8_t ignore)
{
	int min_row, max_row;
	
	ti->publ.row = ti->param_buffer[0] - 1;
	
	if(ti->origin)
	{
		ti->publ.row += ti->top;
		max_row = ti->bottom;
		min_row = ti->top;
	} else
	{
		max_row = ti->publ.rows - 1;
		min_row = 0;
	}


	if(ti->publ.row < min_row)
		ti->publ.row = min_row;
	if(ti->publ.row > max_row)
		ti->publ.row = max_row;
}

static void vt102_curs_place(TermInternal *ti, uint8_t ignore)
{	
	ti->publ.row = ti->param_buffer[0] - 1;
	ti->publ.col = ti->param_buffer[1] - 1;

	if(ti->publ.col < 0)
		ti->publ.col = 0;
	else if(ti->publ.col > (ti->publ.cols - 1))
		ti->publ.col = ti->publ.cols - 1;

	if(ti->publ.row < 0)
		ti->publ.row = 0;
	if(ti->publ.row > (ti->publ.rows - 1))
		ti->publ.row = ti->publ.rows - 1;
}