	/* 0x40... 0x4F */
	{st_vt102_ground, vt102_char_insert},		/* @ */
	{st_vt102_ground, vt102_curs_up},		/* A */
	{st_vt102_ground, vt102_curs_down},		/* B */
	{st_vt102_ground, vt102_curs_right},		/* C */
	
	{st_vt102_ground, vt102_curs_left},		/* D */
	{st_vt102_ground, vt102_curs_line},		/* E */
	{st_vt102_ground, vt102_curs_line},		/* F */
	{st_vt102_ground, vt102_curs_column_absolute},	/* G */
	
	{st_vt102_ground, vt102_curs_place},		/* H */
	{st_vt102_ground, vt102_ht_fwd},		/* I */
	{st_vt102_ground, vt102_disp_erase},		/* J */
	{st_vt102_ground, vt102_line_erase},		/* K */
	
	{st_vt102_ground, vt102_line_insert},		/* L */
	{st_vt102_ground, vt102_line_delete},		/* M */
	{st_vt102_ground, vt102_unknown_csi},		/* N */
	{st_vt102_ground, vt102_unknown_csi},		/* O */

	/* 0x50... 0x5F */
	{st_vt102_ground, vt102_char_delete},		/* P */
	{st_vt102_ground, vt102_unknown_csi},		/* Q */
	{st_vt102_ground, vt102_unknown_csi},		/* R */
	{st_vt102_ground, vt102_disp_scrup},		/* S */
	
	{st_vt102_ground, vt102_disp_scrdn},		/* T */
	{st_vt102_ground, vt102_unknown_csi},		/* U */
	{st_vt102_ground, vt102_unknown_csi},		/* V */
	{st_vt102_ground, vt102_unknown_csi},		/* W */
	
	{st_vt102_ground, vt102_char_erase},		/* X */
	{st_vt102_ground, vt102_unknown_csi},		/* Y */
	{st_vt102_ground, vt102_ht_bwd},		/* Z */
	{st_vt102_ground, vt102_unknown_csi},		/* [ */
	
	{st_vt102_ground, vt102_unknown_csi},		/* \ */
	{st_vt102_ground, vt102_unknown_csi},		/* ] */
	{st_vt102_ground, vt102_unknown_csi},		/* ^ */
	{st_vt102_ground, vt102_unknown_csi},		/* _ */

	/* 0x60... 0x6F */
	{st_vt102_ground, vt102_curs_column},		/* ` */
	{st_vt102_ground, vt102_curs_right},		/* a */
	{st_vt102_ground, vt102_char_rep},		/* b */
	{st_vt102_ground, vt102_id},			/* c */
	
	{st_vt102_ground, vt102_curs_line_absolute},	/* d */
	{st_vt102_ground, vt102_curs_down},		/* e */
	{st_vt102_ground, vt102_curs_place},		/* f */
	{st_vt102_ground, vt102_ht_clear},		/* g */
	
	{st_vt102_ground, vt102_set_mode},		/* h */
	{st_vt102_ground, vt102_unknown_csi},		/* i */
	{st_vt102_ground, vt102_unknown_csi},		/* j */
	{st_vt102_ground, vt102_unknown_csi},		/* k */
	
	{st_vt102_ground, vt102_set_mode},		/* l */
	{st_vt102_ground, vt102_char_attr},		/* m */
	{st_vt102_ground, vt102_status},		/* n */
	{st_vt102_ground, vt102_unknown_csi},		/* o */
	
	/* 0x70... 0x7F */
	{st_vt102_ground, vt102_unknown_csi},		/* p */
	{st_vt102_ground, vt102_leds},			/* q */
	{st_vt102_ground, vt102_scroll_region},		/* r */
	{st_vt102_ground, vt102_curs_save},		/* s */
	
	{st_vt102_ground, vt102_unknown_csi},		/* t */
	{st_vt102_ground, vt102_curs_restore},		/* u */
	{st_vt102_ground, vt102_unknown_csi},		/* v */
	{st_vt102_ground, vt102_unknown_csi},		/* w */
	
	{st_vt102_ground, vt102_unknown_csi},		/* x */
	{st_vt102_ground, vt102_unknown_csi},		/* y */
	{st_vt102_ground, vt102_unknown_csi},		/* z */
	{st_vt102_ground, vt102_unknown_csi},		/* { */
	
	{st_vt102_ground, vt102_unknown_csi},		/* | */
	{st_vt102_ground, vt102_unknown_csi},		/* } */
	{st_vt102_ground, vt102_unknown_csi},		/* ~ */
	{NEXT_STATE, vt102_char_delete},		/* DEL */

