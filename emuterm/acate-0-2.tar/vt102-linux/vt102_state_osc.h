#undef	NEXT_STATE
#undef	ACTION
#define NEXT_STATE	st_vt102_osc_string
#define ACTION		vt102_osc_put

	/* 0x00... 0x07*/
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {st_vt102_ground, vt102_osc_exit},

	/* 0x08... 0x0f*/
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},

	/* 0x10... 0x17*/
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},

	/* 0x18... 0x1f*/
	{st_vt102_ground, vt102_nop}, {NEXT_STATE, vt102_nop},
	{st_vt102_ground, vt102_nop}, {st_vt102_escape, vt102_esc_init},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},

	/* 0x20... 0x7F: */
	#include "state_block_32.h"
	#include "state_block_32.h"
	#include "state_block_32.h"

	/* 0x80... 0x9f: */
	#include "vt102_state_block_0x80-9f.h"

	/* 0xA0... 0xFF: */
	#include "state_block_16.h"
	#include "state_block_32.h"
	#include "state_block_32.h"