static void vt102_scroll_region(TermInternal *ti, uint8_t ignore)
{
	uint16_t newtop, newbottom;

	param(ti, ';');
	
	newtop = ti->param_buffer[0];
	newbottom = ti->param_buffer[1];
		
	if(newtop)
		newtop--;
	
	if(newbottom)
		newbottom--;
	else
		newbottom = ti->publ.rows - 1;

	if(	(newtop < newbottom)	&&
		(newbottom < ti->publ.rows)	)
	{
		ti->top = newtop;
		ti->bottom = newbottom;
	
		ti->publ.col = 0;
		ti->publ.row = 0;
	}
}
