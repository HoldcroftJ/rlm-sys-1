static void vt102_ht(TermInternal* ti, uint8_t data)
{
	for(ti->publ.col++ ;
		(ti->publ.col < ti->publ.cols) && (!ti->tabs[ti->publ.col]);
		ti->publ.col++);	
}

static void vt102_ht_clear(TermInternal *ti, uint8_t ignore)
{
	uint16_t i;
				
	switch(ti->param_buffer[0])
	{
		case 0:		ti->tabs[ti->publ.col] = 0;
				break;
				
		case 3:		for(i = 0; i< ti->publ.cols; i++)
					ti->tabs[i] = 0;
				break;
		default:
				break;
	}
}

static void vt102_ht_set(TermInternal *ti, uint8_t ignore)
{
	ti->tabs[ti->publ.col] = 1;
}

static void vt102_ht_fwd(TermInternal *ti, uint8_t ignore)
{
	uint16_t i;
	
	i = ti->param_buffer[0];
	
	if(!i) i++;

	for(ti->publ.col++; (ti->publ.col <= (ti->publ.cols - 1)) && i; ti->publ.col++)
		if(ti->tabs[ti->publ.col])
			i--;
}

static void vt102_ht_bwd(TermInternal *ti, uint8_t ignore)
{
	uint16_t i;
	
	i = ti->param_buffer[0];
	
	if(!i) i++;

	for(ti->publ.col--; (ti->publ.col >= 0) && i; ti->publ.col--)
		if(ti->tabs[ti->publ.col])
			i--;
}