static void vt102_bell(TermInternal* ti, uint8_t data)
{
	prim_bell(ti);
}

static void vt102_bs(TermInternal* ti, uint8_t data)
{
	if(ti->publ.col)
		ti->publ.col -= 1;
}

static void vt102_lf(TermInternal* ti, uint8_t data)
{
	vt102_curs_index(ti, 0);
}

static void vt102_cr(TermInternal* ti, uint8_t data)
{		
	ti->publ.col = 0;
}

static void vt102_crlf(TermInternal* ti, uint8_t data)
{
	vt102_cr(ti, 0);
	vt102_lf(ti, 0);
}