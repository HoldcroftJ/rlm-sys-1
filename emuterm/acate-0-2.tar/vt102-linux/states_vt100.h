/*
 LICENSE INFORMATION:
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License (LGPL) as published by the Free Software Foundation.
 
 Please refer to the COPYING file for more information.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 
 Copyright (c) 2010 Peter Persson (pep.fishmoose@gmail.com)
 */

#ifndef _vt102_state_DEFS_H_
#define _vt102_state_DEFS_H_

struct state_entry st_vt52_ground[];
struct state_entry st_vt102_ground[];
struct state_entry st_vt102_escape_int[];
struct state_entry st_vt102_escape[];
struct state_entry st_vt102_csi_entry[];
struct state_entry st_vt102_csi_int[];
struct state_entry st_vt102_csi_param[];
struct state_entry st_vt102_csi_ignore[];
struct state_entry st_vt102_osc_string[];

struct state_entry st_vt102_ground[256] =
{
	#undef	NEXT_STATE
	#define NEXT_STATE	st_vt102_ground
	#include "vt102_dispatch_ctrl.h"

	#include "vt102_state_ground.h"
	#include "vt102_state_block_0x80-9f.h"
	#include "vt102_state_ground.h"
};

struct state_entry st_vt102_escape[256] =
{
	#undef	NEXT_STATE
	#define NEXT_STATE	st_vt102_escape
	#include "vt102_dispatch_ctrl.h"

	#include "vt102_state_escape.h"
	#include "vt102_state_block_0x80-9f.h"
	#include "vt102_state_escape.h"
};

struct state_entry st_vt102_escape_int[256] =
{
	#undef	NEXT_STATE
	#define NEXT_STATE	st_vt102_escape_int
	#include "vt102_dispatch_ctrl.h"

	#include "vt102_state_escape_int.h"
	#include "vt102_state_block_0x80-9f.h"
	#include "vt102_state_escape_int.h"
};

struct state_entry st_vt102_csi_entry[256] =
{
	#undef	NEXT_STATE
	#define NEXT_STATE	st_vt102_csi_entry
	#include "vt102_dispatch_ctrl.h"
	
	#include "vt102_state_csi_entry.h"
	#include "vt102_state_block_0x80-9f.h"
	#include "vt102_state_csi_entry.h"
};

struct state_entry st_vt102_csi_ignore[256] =
{
	#undef	NEXT_STATE
	#define NEXT_STATE	st_vt102_csi_ignore
	#include "vt102_dispatch_ctrl.h"
	
	#include "vt102_state_csi_ignore.h"
	#include "vt102_state_block_0x80-9f.h"
	#include "vt102_state_csi_ignore.h"
};

struct state_entry st_vt102_csi_int[256] =
{
	#undef	NEXT_STATE
	#define NEXT_STATE	st_vt102_csi_int
	#include "vt102_dispatch_ctrl.h"
	
	#include "vt102_state_csi_int.h"
	#include "vt102_state_block_0x80-9f.h"
	#include "vt102_state_csi_int.h"
};

struct state_entry st_vt102_csi_param[256] =
{
	#undef	NEXT_STATE
	#define NEXT_STATE	st_vt102_csi_param
	#include "vt102_dispatch_ctrl.h"
	
	#include "vt102_state_csi_param.h"
	#include "vt102_state_block_0x80-9f.h"
	#include "vt102_state_csi_param.h"
};

struct state_entry st_vt102_osc_string[256] =
{
#include "vt102_state_osc.h"
};

#endif