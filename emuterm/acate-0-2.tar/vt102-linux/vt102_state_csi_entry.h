	/* 0x20... 0x2F: Collect */
	#undef	NEXT_STATE
	#undef	ACTION
	#define NEXT_STATE	st_vt102_csi_int
	#define ACTION		collect
	#include "state_block_16.h"

	/* 0x30... 0x39 ( 0123456789 ) */
	{st_vt102_csi_param, param}, {st_vt102_csi_param, param},
	{st_vt102_csi_param, param}, {st_vt102_csi_param, param},
	{st_vt102_csi_param, param}, {st_vt102_csi_param, param},
	{st_vt102_csi_param, param}, {st_vt102_csi_param, param},
	{st_vt102_csi_param, param}, {st_vt102_csi_param, param},

	/* 0x3A (:) */
	{st_vt102_csi_ignore, vt102_nop},
	
	/* 0x3B (;)*/
	{st_vt102_csi_param, param},
	
	/* 0x3C... 0x3F ( <=>? ) */
	{st_vt102_csi_param, collect}, {st_vt102_csi_param, collect},
	{st_vt102_csi_param, collect}, {st_vt102_csi_param, collect},

	/* 0x40... 0x7F */
	#include "vt102_dispatch_csi.h"