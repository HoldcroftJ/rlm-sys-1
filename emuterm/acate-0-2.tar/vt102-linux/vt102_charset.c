static void vt102_charset(TermInternal* ti, uint8_t charset)
{	
	switch(ti->collect_buffer[0])
	{
		case '(': /* G0 */
		{
			switch(charset)
			{
				case 'B': prim_set_g0(ti, 0); break;	/* let G0 point to char lookup table 0 */
				case '0': prim_set_g0(ti, 1); break;	/* let G0 point to char lookup table 1 */
				case 'U': prim_set_g0(ti, 2); break;	/* let G0 point to char lookup table 2 */
				case 'K': prim_set_g0(ti, 3); break;	/* let G0 point to char lookup table 3 */
			}
			break;
		}
		case ')': /* G1 */
		{	switch(charset)
			{
				case 'B': prim_set_g1(ti, 0); break;	/* let G1 point to char lookup table 0 */
				case '0': prim_set_g1(ti, 1); break;	/* let G1 point to char lookup table 1 */
				case 'U': prim_set_g1(ti, 2); break;	/* let G1 point to char lookup table 2 */
				case 'K': prim_set_g1(ti, 3); break;	/* let G1 point to char lookup table 3 */
			}
			break;
		}
	}
}

static void vt102_charset_g0(TermInternal* ti, uint8_t ignore)
{
	prim_use_g0(ti); /* use char lookup G0 */
}

static void vt102_charset_g1(TermInternal* ti, uint8_t ignore)
{
	prim_use_g1(ti); /* use char lookup G1 */
}