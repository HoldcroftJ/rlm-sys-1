	/* 0x00... 0x07*/
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_bell},

	/* 0x08... 0x0f*/
	{NEXT_STATE, vt102_bs},	{NEXT_STATE, vt102_ht},
	{NEXT_STATE, vt102_crlf},	{NEXT_STATE, vt102_lf},
	{NEXT_STATE, vt102_lf}, {NEXT_STATE, vt102_cr},
	{NEXT_STATE, vt102_charset_g1},{NEXT_STATE, vt102_charset_g0},

	/* 0x10... 0x17*/
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},

	/* 0x18... 0x1f*/
	{st_vt102_ground, vt102_nop}, {NEXT_STATE, vt102_nop},
	{st_vt102_ground, vt102_nop}, {st_vt102_escape, vt102_esc_init},
	
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
	{NEXT_STATE, vt102_nop}, {NEXT_STATE, vt102_nop},
