static void vt102_bell(TermInternal* ti, uint8_t data);
static void vt102_bs(TermInternal* ti, uint8_t data);
static void vt102_lf(TermInternal* ti, uint8_t data);
static void vt102_cr(TermInternal* ti, uint8_t data);
static void vt102_crlf(TermInternal* ti, uint8_t data);
static void vt102_ht(TermInternal* ti, uint8_t data);
static void vt102_ht_clear(TermInternal* ti, uint8_t ignore);
static void vt102_ht_set(TermInternal* ti, uint8_t ignore);
static void vt102_ht_fwd(TermInternal* ti, uint8_t data);
static void vt102_ht_bwd(TermInternal* ti, uint8_t data);

static void vt102_charset(TermInternal* ti, uint8_t charset);
static void vt102_charset_g0(TermInternal* ti, uint8_t ignore);
static void vt102_charset_g1(TermInternal* ti, uint8_t ignore);
static void vt102_esc_init(TermInternal* ti, uint8_t data);
static void csi_reset(TermInternal* ti, uint8_t data);
static void param(TermInternal* ti, uint8_t data);
static void collect(TermInternal* ti, uint8_t data);

static void vt102_line_delete(TermInternal* ti, uint8_t ignore);
static void vt102_line_insert(TermInternal* ti, uint8_t ignore);
static void vt102_line_erase(TermInternal* ti, uint8_t ignore);

static void vt102_char_delete(TermInternal* ti, uint8_t ignore);
static void vt102_char_insert(TermInternal* ti, uint8_t ignore);
static void vt102_char_erase(TermInternal* ti, uint8_t ignore);
static void vt102_char_attr(TermInternal* ti, uint8_t ignore);
static void vt102_char_rep(TermInternal* ti, uint8_t data);
static void vt102_char_put(TermInternal* ti, uint8_t data);

static void vt102_scroll_region(TermInternal* ti, uint8_t ignore);

static void vt102_disp_erase(TermInternal* ti, uint8_t ignore);
static void vt102_disp_scrup(TermInternal* ti, uint8_t ignore);
static void vt102_disp_scrdn(TermInternal* ti, uint8_t ignore);

static void vt102_curs_save_attr(TermInternal* ti, uint8_t ignore);
static void vt102_curs_restore_attr(TermInternal* ti, uint8_t ignore);
static void vt102_curs_save(TermInternal* ti, uint8_t ignore);
static void vt102_curs_restore(TermInternal* ti, uint8_t ignore);
static void vt102_curs_index(TermInternal* ti, uint8_t ignore);
static void vt102_curs_index_rev(TermInternal* ti, uint8_t ignore);
static void vt102_curs_up(TermInternal* ti, uint8_t ignore);
static void vt102_curs_down(TermInternal* ti, uint8_t ignore);
static void vt102_curs_left(TermInternal* ti, uint8_t ignore);
static void vt102_curs_right(TermInternal* ti, uint8_t ignore);
static void vt102_curs_line_absolute(TermInternal* ti, uint8_t ignore);
static void vt102_curs_line(TermInternal* ti, uint8_t ignore);
static void vt102_curs_column_absolute(TermInternal* ti, uint8_t ignore);
static void vt102_curs_column(TermInternal* ti, uint8_t ignore);
static void vt102_curs_place(TermInternal* ti, uint8_t ignore);

static void vt102_set_mode(TermInternal* ti, uint8_t command);
static void vt102_unknown_csi(TermInternal* ti, uint8_t data);
static void vt102_id(TermInternal* ti, uint8_t ignore);
static void vt102_reset(TermInternal* ti, uint8_t ignore);
static void vt102_sharp(TermInternal* ti, uint8_t data);
static void vt102_status(TermInternal* ti, uint8_t ignore);
static void vt102_leds(TermInternal* ti, uint8_t ignore);

static void vt102_osc_init(TermInternal* ti, uint8_t ignore);
static void vt102_osc_exit(TermInternal* ti, uint8_t data);
static void vt102_osc_put(TermInternal* ti, uint8_t data);

static void vt102_nop(TermInternal* ti, uint8_t data);

#include "states_vt100.h"

#include "vt102_misc.c"
#include "vt102_osc.c"
#include "vt102_control.c"
#include "vt102_charset.c"
#include "vt102_char.c"
#include "vt102_cursor.c"
#include "vt102_line.c"
#include "vt102_display.c"
#include "vt102_scroll.c"
#include "vt102_tab.c"