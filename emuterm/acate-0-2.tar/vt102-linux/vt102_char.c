static void vt102_char_delete(TermInternal *ti, uint8_t ignore)
{
	prim_delete(ti, ti->param_buffer[0] ? ti->param_buffer[0]  : 1);
}

static void vt102_char_insert(TermInternal *ti, uint8_t ignore)
{
	prim_insert(ti, ti->param_buffer[0] ? ti->param_buffer[0]  : 1);
}

static void vt102_char_erase(TermInternal *ti, uint8_t ignore)
{
	prim_erase(ti, ti->param_buffer[0] ? ti->param_buffer[0]  : 1);
}

static void vt102_char_attr(TermInternal *ti, uint8_t ignore)
{
	uint16_t i;
	
	if(ti->collect_buffer[0] == '?')
		return;
	
	param(ti, ';');

	for(i = 0; i < ti->param_position; i++)
	{
		switch(ti->param_buffer[i])
		{
			case 0:	ti->cur.full		= ti->def.full;
				ti->cur.half		= ti->def.half;
				ti->cur.italics		= ti->def.italics;
				ti->cur.underline	= ti->def.underline;
				ti->cur.blink		= ti->def.blink;
				ti->cur.reverse		= ti->def.reverse;
				ti->cur.bg		= ti->def.bg;
				ti->cur.fg		= ti->def.fg;
				break;
			
			case 1:	ti->cur.full		= true;	break;
			case 2:	ti->cur.half		= true; break;
			case 3: ti->cur.italics		= true;	break;
			case 4:	ti->cur.underline	= true;	break;
			case 5:	ti->cur.blink		= true;	break;
			case 7:	ti->cur.reverse		= true;	break;
			
			case 10:	prim_set_g_cur(ti, 0);
						ti->disp_ctrl = false;
						break; 	/* ISO  */
				
			case 11:	prim_set_g_cur(ti, 2);	/* PC  */
						ti->disp_ctrl = true;
						break;
				
			case 12:	prim_set_g_cur(ti, 2);	/* PC  */
						ti->disp_ctrl = true;
						break;
				
			case 21:	ti->cur.full		= false; break;
			case 22:	ti->cur.half		= false; break;
			case 23:	ti->cur.italics		= false; break;			
			case 24:	ti->cur.underline	= false; break;
			case 25:	ti->cur.blink		= false; break;
			case 27:	ti->cur.reverse		= false; break;
						
			/* set foreground */
			case 30: case 31: case 32: case 33:
			case 34: case 35: case 36: case 37:
				ti->cur.fg = ti->param_buffer[i] - 30;
				break;
				
			/* set background */
			case 40: case 41: case 42: case 43:
			case 44: case 45: case 46: case 47:
				ti->cur.bg = ti->param_buffer[i] - 40;
				break;
			
			/* defaults */
			case 38:	ti->cur.fg		= ti->def.fg;
					ti->cur.underline	= true;
					break;
					
			case 39:	ti->cur.fg		= ti->def.fg;
					ti->cur.underline	= false;
					break;
					
			case 49:	ti->cur.bg		= ti->def.bg;
					break;		
		}
	}
	
	prim_compile_attr(ti);	
}

static void vt102_char_rep(TermInternal *ti, uint8_t ignore)
{
	uint16_t i;
			
	for(i = 0; i < ti->param_buffer[0] ? ti->param_buffer[0]  : 1; i++)
		vt102_char_put(ti, ti->cur.latched_char);
}

static void vt102_char_put(TermInternal *ti, uint8_t data)
{
	ti->cur.latched_char = data;

	if (ti->publ.col >= ti->publ.cols)
	{
		ti->publ.col = 0;
		vt102_curs_index(ti,0);
	}
	
	if(ti->insert)
		prim_insert(ti, 1);
	
	prim_put(ti, data);

	ti->publ.col++;
}

static void vt102_char_put_0x8x_0x9x(TermInternal *ti, uint8_t data)
{
}