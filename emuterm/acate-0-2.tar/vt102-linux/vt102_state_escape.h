	/* 0x20... 0x2f */
	#undef	NEXT_STATE
	#undef	ACTION
	#define NEXT_STATE	st_vt102_escape_int
	#define	ACTION		collect
	#include "state_block_16.h"
	
	/* 0x30... 0x7F */
	#include "vt102_dispatch_esc.h"