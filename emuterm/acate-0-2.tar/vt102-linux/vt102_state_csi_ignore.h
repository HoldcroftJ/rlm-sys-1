	/* 0x20... 0x3F: Ignore */
	#undef	NEXT_STATE
	#undef	ACTION
	#define NEXT_STATE	st_vt102_csi_ignore
	#define ACTION		vt102_nop
	#include "state_block_32.h"

	/* 0x40... 0x7E */
	#undef	NEXT_STATE
	#undef	ACTION
	#define NEXT_STATE	st_vt102_ground
	#define ACTION		vt102_nop
	#include "state_block_32.h"
	#include "state_block_16.h"
	#include "state_block_8.h"
	
	{NEXT_STATE, ACTION}, {NEXT_STATE, ACTION},
	{NEXT_STATE, ACTION}, {NEXT_STATE, ACTION},
	{NEXT_STATE, ACTION}, {NEXT_STATE, ACTION},
	{NEXT_STATE, ACTION},
	
	/* 0x7F: Ignore */
	{st_vt102_csi_ignore, vt102_char_delete},