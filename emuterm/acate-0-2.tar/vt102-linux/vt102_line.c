static void vt102_line_delete(TermInternal *ti, uint8_t ignore)
{
	uint16_t nr;

	nr = ti->param_buffer[0] ? ti->param_buffer[0]  : 1;

	if(nr > (ti->publ.rows - ti->publ.row))
		nr = ti->publ.rows - ti->publ.row;
	
	while(nr--)
		prim_scroll_up(ti, ti->publ.row, ti->bottom);
}

static void vt102_line_insert(TermInternal *ti, uint8_t ignore)
{
	uint16_t nr;

	nr = ti->param_buffer[0] ? ti->param_buffer[0]  : 1;

	if(nr > (ti->publ.rows - ti->publ.row))
		nr = ti->publ.rows - ti->publ.row;
	
	while(nr--)
		prim_scroll_down(ti, ti->publ.row, ti->bottom);
}


static void vt102_line_erase(TermInternal *ti, uint8_t ignore)
{
	switch (ti->param_buffer[0])
	{
		case 0:	prim_erase_line_fromcursor(ti);		break;
		case 1: prim_erase_line_tocursor(ti);		break;
		case 2:	prim_erase_line(ti, ti->publ.row);	break;
	}
}
