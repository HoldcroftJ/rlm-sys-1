	#undef	NEXT_STATE
	#undef	ACTION
	#define NEXT_STATE	st_vt102_ground
	#define ACTION		vt102_char_put
	
	/* 0x20... 0x7F: Dispatch */	
	#include "state_block_32.h"	
	#include "state_block_32.h"	
	#include "state_block_16.h"
	#include "state_block_8.h"
	
	{NEXT_STATE, ACTION}, {NEXT_STATE, ACTION},
	{NEXT_STATE, ACTION}, {NEXT_STATE, ACTION},
	{NEXT_STATE, ACTION}, {NEXT_STATE, ACTION},
	{NEXT_STATE, ACTION}, {st_vt102_ground, vt102_char_delete},
