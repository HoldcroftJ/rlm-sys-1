static void vt102_osc_init(TermInternal *ti, uint8_t ignore)
{
	prim_osc_init(ti);
}

static void vt102_osc_put(TermInternal *ti, uint8_t data)
{
	prim_osc_put(ti, data);
}

static void vt102_osc_exit(TermInternal *ti, uint8_t data)
{
	prim_osc_send(ti, data);
}