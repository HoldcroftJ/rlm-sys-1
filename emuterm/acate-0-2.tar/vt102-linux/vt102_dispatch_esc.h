	/* 0x30... 0x3F */
	{st_vt102_ground, vt102_charset},		/* 0 */
	{st_vt102_ground, vt102_charset},		/* 1 */
	{st_vt102_ground, vt102_charset},		/* 2 */
	{st_vt102_ground, vt102_sharp},		/* 3 */
	
	{st_vt102_ground, vt102_sharp},		/* 4 */
	{st_vt102_ground, vt102_sharp},		/* 5 */
	{st_vt102_ground, vt102_sharp},		/* 6 */
	{st_vt102_ground, vt102_curs_save_attr},	/* 7 */
	
	{st_vt102_ground, vt102_sharp},		/* 8 */
	{st_vt102_ground, vt102_nop},			/* 9 */
	{st_vt102_ground, vt102_nop},			/* : */
	{st_vt102_ground, vt102_nop},			/* ; */
	
	{st_vt102_ground, vt102_nop},			/* < */
	{st_vt102_ground, vt102_nop},			/* = */
	{st_vt102_ground, vt102_nop},			/* > */
	{st_vt102_ground, vt102_nop},			/* ? */

	/* 0x40... 0x4F */
	{st_vt102_ground, vt102_nop},			/* @ */
	{st_vt102_ground, vt102_charset},		/* A */
	{st_vt102_ground, vt102_charset},		/* B */
	{st_vt102_ground, vt102_nop},			/* C */
	
	{st_vt102_ground, vt102_lf},			/* D */
	{st_vt102_ground, vt102_crlf},		/* E */
	{st_vt102_ground, vt102_nop},			/* F */
	{st_vt102_ground, vt102_nop},			/* G */
	
	{st_vt102_ground, vt102_ht_set},		/* H */
	{st_vt102_ground, vt102_nop},			/* I */
	{st_vt102_ground, vt102_nop},			/* J */
	{st_vt102_ground, vt102_charset},		/* K */
	
	{st_vt102_ground, vt102_nop},			/* L */
	{st_vt102_ground, vt102_curs_index_rev},	/* M */
	{st_vt102_ground, vt102_nop},			/* N */
	{st_vt102_ground, vt102_nop},			/* O */

	/* 0x50... 0x5F */
	{st_vt102_ground, vt102_nop},			/* P */
	{st_vt102_ground, vt102_nop},			/* Q */
	{st_vt102_ground, vt102_nop},			/* R */
	{st_vt102_ground, vt102_nop},			/* S */
	
	{st_vt102_ground, vt102_nop},			/* T */
	{st_vt102_ground, vt102_charset},		/* U */
	{st_vt102_ground, vt102_nop},			/* V */
	{st_vt102_ground, vt102_nop},			/* W */
	
	{st_vt102_ground, vt102_nop},			/* X */
	{st_vt102_ground, vt102_nop},			/* Y */
	{st_vt102_ground, vt102_id},			/* Z */
	{st_vt102_csi_entry, vt102_esc_init},	/* [ */
	
	{st_vt102_ground, vt102_osc_exit},		/* \ */
	{st_vt102_osc_string, vt102_osc_init},	/* ] */
	{st_vt102_ground, vt102_nop},			/* ^ */
	{st_vt102_ground, vt102_nop},			/* _ */

	/* 0x60... 0x6F */
	{st_vt102_ground, vt102_nop},			/* ` */
	{st_vt102_ground, vt102_nop},			/* a */
	{st_vt102_ground, vt102_nop},			/* b */
	{st_vt102_ground, vt102_reset},			/* c */
	
	{st_vt102_ground, vt102_nop},			/* d */
	{st_vt102_ground, vt102_nop},			/* e */
	{st_vt102_ground, vt102_nop},			/* f */
	{st_vt102_ground, vt102_nop},			/* g */
	
	{st_vt102_ground, vt102_nop},			/* h */
	{st_vt102_ground, vt102_nop},			/* i */
	{st_vt102_ground, vt102_nop},			/* j */
	{st_vt102_ground, vt102_nop},			/* k */
	
	{st_vt102_ground, vt102_nop},			/* l */
	{st_vt102_ground, vt102_nop},			/* m */
	{st_vt102_ground, vt102_nop},			/* n */
	{st_vt102_ground, vt102_nop},			/* o */
	
	/* 0x70... 0x7F */
	{st_vt102_ground, vt102_nop},			/* p */
	{st_vt102_ground, vt102_nop},			/* q */
	{st_vt102_ground, vt102_nop},			/* r */
	{st_vt102_ground, vt102_nop},			/* s */
	
	{st_vt102_ground, vt102_nop},			/* t */
	{st_vt102_ground, vt102_nop},			/* u */
	{st_vt102_ground, vt102_nop},			/* v */
	{st_vt102_ground, vt102_nop},			/* w */
	
	{st_vt102_ground, vt102_nop},			/* x */
	{st_vt102_ground, vt102_nop},			/* y */
	{st_vt102_ground, vt102_nop},			/* z */
	{st_vt102_ground, vt102_nop},			/* { */
	
	{st_vt102_ground, vt102_nop},			/* | */
	{st_vt102_ground, vt102_nop},			/* } */
	{st_vt102_ground, vt102_nop},			/* ~ */
	{NEXT_STATE, vt102_char_delete},		/* DEL */

