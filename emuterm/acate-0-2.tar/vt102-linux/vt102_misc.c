static void vt102_nop(TermInternal *ti, uint8_t data)
{
	//printf("unknown escape sequence\r\n");
}

static void vt102_unknown_csi(TermInternal *ti, uint8_t data)
{
	//printf("Unknown CSI detected: '%c'\n", data);
}

static void vt102_esc_init(TermInternal *ti, uint8_t ignore)
{
	ti->param_position	= 0;
	ti->param_buffer[0]	= ti->param_buffer[1] = ti->param_buffer[2] = 0;
	ti->collect_buffer[0]	= ti->collect_buffer[1] = 0;
}

static void collect(TermInternal *ti, uint8_t data)
{
	if(ti->param_position < BUF_SIZE)
		ti->collect_buffer[ti->param_position] = data;
}
static void param(TermInternal *ti, uint8_t data)
{
	if(ti->param_position < BUF_SIZE)
	{
		switch(data)
		{
			case '0': case '1': case '2': case '3': case '4':
			case '5': case '6': case '7': case '8': case '9':
				ti->param_buffer[ti->param_position] *= 10;
				ti->param_buffer[ti->param_position] += (data - '0');
				break;
				
			case ';':
				ti->param_buffer[++ti->param_position] = 0;
				break;
		}
	}
}

static void vt102_set_mode(TermInternal *ti, uint8_t command)
{
	uint16_t i;
	
	param(ti, ';');
	
	for(i = 0; i < ti->param_position; i++)
	{
		if(ti->collect_buffer[i] == '?')
		{
			switch(ti->param_buffer[i])
			{
				case 1:		ti->keymode	= command == 'h'; break;
				case 2:		if(command == 'h')
								prim_go_vt52(ti);
							else
								prim_go_vt102(ti);
							break;
				case 3:		ti->col132		= command == 'h'; break;
				case 4:		ti->scroll		= command == 'h'; break;
				case 5:		ti->reverse	= command == 'h'; break;
				case 6:		ti->origin 	= command == 'h'; break;
				case 7:		ti->wrap		= command == 'h'; break;
				case 8:		ti->repeat		= command == 'h'; break;
				case 9:		ti->publ.mouse_mode 	= (command == 'h') ? 1: 0;
					break;
				case 25:	ti->publ.curs_mode		= command == 'h'; break;
				case 1000:	ti->publ.mouse_mode 	= (command == 'h') ? 2: 0;
					break;
					
			}
		}
		else
		{
			switch(ti->param_buffer[i])
			{
				case 3:		ti->disp_ctrl	= command == 'h'; break;
				case 4:		ti->insert		= command == 'h'; break;
				case 20:	ti->lf_mode	= command == 'h'; break;
			}
		}
	}
}

static void vt102_id(TermInternal *ti, uint8_t ignore)
{
	param(ti, ';');
	
	if(ti->collect_buffer[0] == 0)
	{
		if(ti->param_buffer[0] == 0)
			acate_send((Terminal*)ti, "\033[?6c", 0);	/* VT102 ID */
	} else if (ti->collect_buffer[0] == '>')
	{
		if(ti->param_buffer[0] == 0)
			acate_send((Terminal*)ti, "\033[>0;95;0c", 0); /* VT100, some number, rom cart reg no. (always 0) */
	}
}

static void vt102_reset(TermInternal *ti, uint8_t ignore)
{
	int16_t i,j;

	/* reset cursor position */
	ti->publ.row = ti->publ.col = 0;

	/* initial scrolling area is the whole window */
	ti->top = 0;
	ti->bottom = ti->publ.rows - 1;

	/* initial terminal settings */
	ti->keymode			= false;
	ti->vt52			= false;
	ti->col132			= false;
	ti->scroll			= false;
	ti->reverse			= false;
	ti->origin			= false;
	ti->wrap			= true;
	ti->repeat			= true;
	ti->publ.mouse_mode	= 0;
	ti->publ.curs_mode	= true;
	ti->disp_ctrl		= false;
	ti->insert			= false;
	ti->lf_mode			= false;
	
	/* initialize TAB-array */
	memset(ti->tabs, 0, sizeof(uint8_t) * ti->publ.cols);
	for(i = 0; i<ti->publ.cols; i += 8)
		ti->tabs[i] = 1;
	
	/* set default attribute settings */
	memcpy(&ti->cur, &ti->def, sizeof(struct attribute));
	prim_compile_attr(ti); 
	
	/* clear cell matrix */
	for(i = 0; i < ti->publ.rows; i++)
	{
		ti->publ.line_dirty[i]	= true;
		ti->publ.linemode[i]	= 0;
		
		for(j = 0; j < ti->publ.cols; j++)
			ti->publ.cells[i][j] = ti->cur.attr | ' ';
		
	}
}

static void vt102_sharp(TermInternal *ti, uint8_t data)
{
	uint16_t i,j;
	
	if(ti->collect_buffer[0] == '#')
	{
		switch(data)
		{
			case '3':	/* double height, double width, top half */
				ti->publ.linemode[ti->publ.row] = 1;
				ti->publ.line_dirty[ti->publ.row] = true;
				for(i = (ti->publ.cols / 2); i < ti->publ.cols; i++)
					ti->publ.cells[ti->publ.row][i] = ti->cur.attr | ' ';
				break;
				
			case '4':	/* double height, double width, bottom half */
				ti->publ.linemode[ti->publ.row] = 2;
				ti->publ.line_dirty[ti->publ.row] = true;
				for(i = (ti->publ.cols / 2); i < ti->publ.cols; i++)
					ti->publ.cells[ti->publ.row][i] = ti->cur.attr | ' ';
				break;
				
			case '5':	/* single width, single height */
				ti->publ.linemode[ti->publ.row] = 0;
				ti->publ.line_dirty[ti->publ.row] = true;
				break;
				
			case '6':	/* double width */
				ti->publ.linemode[ti->publ.row] = 3;
				ti->publ.line_dirty[ti->publ.row] = true;
				for(i = (ti->publ.cols / 2); i < ti->publ.cols; i++)
					ti->publ.cells[ti->publ.row][i] = ti->cur.attr | ' ';
				break;
				
			case '8':
				for (ti->publ.row = 0; ti->publ.row < ti->publ.rows; ti->publ.row++)
				{
					ti->publ.linemode[ti->publ.row] = 0;
					for (ti->publ.col = 0; ti->publ.col < ti->publ.cols; ti->publ.col++)
						prim_put(ti, 'E');
				}
				break;
		}
	} else
		vt102_curs_restore_attr(ti, 0);
}

static void vt102_status(TermInternal *ti, uint8_t ignore)
{
	static char buf[40];
	
	param(ti, ';'); /* rätt? */
	
	if(ti->collect_buffer[0] != '?')
	{
		switch(ti->param_buffer[0])
		{
			case 5:	acate_send((Terminal*)ti, "\033[0n", 0);
				break;
				
			case 6:	sprintf(buf, "\033[%d;%dR",
							ti->publ.row + (ti->origin ? ti->top + 1 : 1),
							ti->publ.col + 1);
				
				acate_send((Terminal*)ti, buf, 0);
				break;
		}
	}
}

static void vt102_leds(TermInternal *ti, uint8_t ignore)
{
	
}