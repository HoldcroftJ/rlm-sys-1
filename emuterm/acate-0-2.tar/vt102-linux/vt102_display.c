static void vt102_disp_erase(TermInternal *ti, uint8_t ignore)
{
	uint16_t i;
		
	switch(ti->param_buffer[0])
	{
		case 0:	prim_erase_disp_fromcursor(ti);		break;
		case 1:	prim_erase_disp_tocursor(ti);		break;
		case 2: prim_erase_disp(ti);

			for(i = 0; i<ti->publ.rows; i++)
				ti->publ.linemode[i]	= 0;	
			
			break;
	}
}

static void vt102_disp_scrup(TermInternal *ti, uint8_t ignore)
{
	prim_scroll_up(ti, ti->top, ti->bottom);
}

static void vt102_disp_scrdn(TermInternal *ti, uint8_t ignore)
{
	prim_scroll_down(ti, ti->top, ti->bottom);
}