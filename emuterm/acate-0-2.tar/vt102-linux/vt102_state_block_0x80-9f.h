	/* 0x80... 0x8f */
	{st_vt102_ground, vt102_nop}, {st_vt102_ground, vt102_nop},
	{st_vt102_ground, vt102_nop}, {st_vt102_ground, vt102_nop},

	{st_vt102_ground, vt102_lf},  {st_vt102_ground, vt102_crlf},
	{st_vt102_ground, vt102_nop}, {st_vt102_ground, vt102_nop},
	
	{st_vt102_ground, vt102_ht_set}, {st_vt102_ground, vt102_nop},
	{st_vt102_ground, vt102_nop}, {st_vt102_ground, vt102_nop},
	{st_vt102_ground, vt102_nop}, {st_vt102_ground, vt102_curs_index_rev},
	{st_vt102_ground, vt102_nop}, {st_vt102_ground, vt102_nop},
	
	/* 0x90... 0x97 */
	{st_vt102_ground, vt102_nop}, {st_vt102_ground, vt102_nop},
	{st_vt102_ground, vt102_nop}, {st_vt102_ground, vt102_nop},
	{st_vt102_ground, vt102_nop}, {st_vt102_ground, vt102_nop},
	{st_vt102_ground, vt102_nop}, {st_vt102_ground, vt102_nop},

	/* 0x98... 0x9b */
	{st_vt102_ground, vt102_nop}, {st_vt102_ground, vt102_nop},
	{st_vt102_ground, vt102_id}, {st_vt102_csi_entry, vt102_esc_init},

	/* 0x9c... 0x9f */
	{st_vt102_ground, vt102_osc_exit}, {st_vt102_osc_string, vt102_osc_init},
	{st_vt102_ground, vt102_nop}, {st_vt102_ground, vt102_nop},
