/*
 LICENSE INFORMATION:
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License (LGPL) as published by the Free Software Foundation.
 
 Please refer to the COPYING file for more information.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 
 Copyright (c) 2010 Peter Persson (pep.fishmoose@gmail.com)
 */

#include <osbind.h>

#include "private.h"

#define SCRATCH_SIZE	200000
static uint8_t*	scratch = NULL;		/* global scratch buffer */
static bool initialized = false;	/* if true, easy_pty is initialized */

extern struct state_entry st_vt102_ground[];

#define size(cols,rows,scrollback)	\
(	\
(cols * sizeof(uint16_t)) * (rows + scrollback) + 		/* character cells + scrollback */ \
(rows * sizeof(uint16_t)) +								/* linemode */ \
(sizeof(bool) * rows) +									/* line dirty */ \
(sizeof(uint8_t) * cols) +								/* TAB array */ \
(sizeof(uint16_t*) * rows) +							/* Cell Line array */ \
(sizeof(uint16_t*) * rows)								/* Log Line array */	\
)

static void set_buffers(TermInternal* ti)
{
	int16_t i, j;
	uint8_t *ptr;
	
	/* setup buffers */
	ptr = ti->buffer;
	
	/* clear buffer */
	memset(ptr, 0, ti->bufsize);

	/* set up dynamic buffers */
	ti->publ.linemode	= ptr;		ptr += sizeof(uint16_t) * ti->publ.rows;
	ti->publ.line_dirty	= ptr;		ptr += sizeof(bool) * ti->publ.rows;
	ti->tabs			= ptr;		ptr += sizeof(uint8_t) * ti->publ.cols;
	ti->publ.cells		= ptr;		ptr += sizeof(uint16_t*) * ti->publ.rows;
	ti->publ.log		= ptr;		ptr += sizeof(uint16_t*) * ti->publ.logmax;
	
	for (i = 0; i < ti->publ.rows; i++)
	{
		ti->publ.cells[i] = ptr;
		for(j = 0; j < ti->publ.cols; j++)
			ti->publ.cells[i][j] = ti->cur.attr | ' ';
		
		ptr += sizeof(uint16_t) * ti->publ.cols;
	}
	
	for (i = 0; i < ti->publ.logmax; i++)
	{
		ti->publ.log[i] = ptr;
		for(j = 0; j < ti->publ.cols; j++)
			ti->publ.log[i][j] = ti->cur.attr | ' ';
		
		ptr += sizeof(uint16_t) * ti->publ.cols;
	}
	
	/* flag everything for redraw */
	for(i = 0; i < ti->publ.rows; i++)
		ti->publ.line_dirty[i] = true;
	
	ti->publ.curpos_dirty	= true;
	
	/* reset scroll region */
	ti->top		= 0;
	ti->bottom	= ti->publ.rows - 1;
	
	/* ensure cursors are within bounds */
	if(ti->publ.row >= ti->publ.rows)
		ti->publ.row = ti->publ.rows - 1;
	
	if(ti->publ.col >= ti->publ.cols)
		ti->publ.col = ti->publ.cols - 1;
	
	if(ti->publ.mouse_row >= ti->publ.rows)
		ti->publ.mouse_row = ti->publ.rows - 1;
	
	if(ti->publ.mouse_col >= ti->publ.cols)
		ti->publ.mouse_col = ti->publ.cols - 1;
	
	/* reset log */
	ti->publ.logpos			= 0;
	ti->publ.logsiz			= 0;
	ti->publ.logchanged		= true;		
}

static bool alloc_buffers(TermInternal* ti)
{
	uint32_t	reqsize;
	uint8_t		*ptr;
	
	if(!(ptr = realloc(ti->buffer, reqsize = 1.5 * size(ti->publ.cols, ti->publ.rows, ti->publ.logmax))))
		if(!(ptr = realloc(ti->buffer, reqsize = size(ti->publ.cols, ti->publ.rows, ti->publ.logmax))))
			return false;
	
	ti->bufsize = reqsize;
	ti->buffer	= ptr;
	
	return true;
}

static bool acate_init()
{
	/* allocate global scratch buffer */
	if(!(scratch = calloc(1,SCRATCH_SIZE)))
		return false;
	
	initialized = true;
	return true;
}

void acate_send(Terminal* rt, uint8_t* data, size_t len)
{	
	TermInternal* ti = (TermInternal*)rt;
	
	if(ti->publ.callback_write)
	{
		if(!len)
			len = strlen(data);
		
		ti->publ.callback_write(ti->publ.parent_ref, data, len);
	}
}

Terminal* acate_create(uint16_t rows, uint16_t cols, uint16_t scrollback, uint16_t fg, uint16_t bg, uint8_t** encoding)
{
	uint16_t i, j;
	
	TermInternal* ti;
	
	if(!initialized)
		if(!acate_init())
			return NULL;	
	
	if((rows <= 0) || (cols <= 0))
		return NULL;
	
	if(!(ti = (TermInternal*)calloc(sizeof(TermInternal), 1)))
		return NULL;
	
	/* terminal dimensions */
	ti->publ.rows			= rows;
	ti->publ.cols			= cols;
	
	/* log buffer */
	ti->publ.logpos			= 0;
	ti->publ.logsiz			= 0;
	ti->publ.logmax			= scrollback;
	ti->publ.logchanged		= true;
	
	/* default attributes */
	ti->def.full			= false;
	ti->def.half			= false;
	ti->def.italics			= false;
	ti->def.underline		= false;
	ti->def.blink			= false;
	ti->def.reverse			= false;
	ti->def.bg				= bg;
	ti->def.fg				= fg;
	ti->def.current_g		= 0;
	ti->def.charset_g[0]	= encoding[0];
	ti->def.charset_g[1]	= encoding[1];
	
	/* character lookup */
	ti->char_lookup			= encoding;
	
	/* initial state = VT102 */
	ti->state = st_vt102_ground;
	
	/* allocate buffers */
	if(!alloc_buffers(ti))
	{
		free(ti);
		return NULL;
	}
	
	set_buffers(ti);
	
	/* issue reset sequence to terminal */
	acate_inject((Terminal*)ti, "\033c", 0);
	
	return (Terminal*)ti;
}

void acate_destroy(Terminal* rt)
{
	uint16_t i;
	
	TermInternal* ti = (TermInternal*)rt;
	
	if (!ti)
		return;
	
	free(ti->buffer);
	free(ti);
}

void acate_migrate(Terminal* dst, Terminal* src)
{
	int16_t		i;
	int16_t		linelen;

	TermInternal tmp;
	
	TermInternal* ti_src = (TermInternal*)src;	
	TermInternal* ti_dst = (TermInternal*)dst;	

	memcpy(&tmp, ti_src, sizeof(TermInternal));
	
	tmp.bufsize			= ti_dst->bufsize;
	tmp.buffer			= ti_dst->buffer;
	tmp.publ.rows		= ti_dst->publ.rows;
	tmp.publ.cols		= ti_dst->publ.cols;
	tmp.publ.logmax		= ti_dst->publ.logmax;
	tmp.publ.parent_ref	= ti_dst->publ.parent_ref;

	memcpy(ti_dst, &tmp, sizeof(TermInternal));

	set_buffers(ti_dst);

	/* copy character image */
	linelen = sizeof(int16_t) * ((ti_dst->publ.cols < ti_src->publ.cols) ? ti_dst->publ.cols : ti_src->publ.cols);
	
	for(i = 0; i < ((ti_dst->publ.rows < ti_src->publ.rows) ? ti_dst->publ.rows : ti_src->publ.rows); i++)
		memcpy(ti_dst->publ.cells[i], ti_src->publ.cells[i], linelen);
}

bool acate_can_resize(Terminal* rt, uint16_t rows, uint16_t cols)
{
	TermInternal* tmp;
	TermInternal* ti = (TermInternal*)rt;	
	
	/* if buffer is too small to cater for the new size, reject */
	if(ti->bufsize < size(cols, rows, ti->publ.logmax))
		return false;
	
	/* if buffer is much larger than the required size, reject */
	if(ti->bufsize > (3 * size(cols, rows, ti->publ.logmax)))
		return false;
	
	/* resize accepted! */
	return true;
}

bool acate_resize(Terminal* rt, uint16_t rows, uint16_t cols)
{
	int16_t i;
	int16_t linelen;
	int16_t oldrows, oldcols;
	
	TermInternal* ti = (TermInternal*)rt;	
	
	if(!(acate_can_resize(rt, rows, cols)))
		return false;
	
	oldrows			= ti->publ.rows;
	oldcols			= ti->publ.cols;
	ti->publ.rows	= rows;
	ti->publ.cols	= cols;
	
	linelen = sizeof(int16_t) * ((oldcols < cols) ? oldcols : cols);
	
	/* save character image */
	for(i = 0; i < oldrows; i++)
		memcpy(&scratch[i * linelen], ti->publ.cells[i], linelen);
	
	/* reset buffers */
	set_buffers(ti);
	
	/* restore character image */
	for(i = 0; i < ((oldrows < rows) ? oldrows : rows); i++)
		memcpy(ti->publ.cells[i], &scratch[i * linelen], linelen);
	
	return true;
}

void acate_cleanup(Terminal* rt)
{
	ptrdiff_t	diff;
	int16_t		i;
	uint32_t	reqsize;
	uint8_t*	ptr;
	TermInternal* ti = (TermInternal*)rt;	
		
	/* reallocate buffer storage */
	if(!(ptr = realloc(ti->buffer, reqsize = size(ti->publ.cols, ti->publ.rows, ti->publ.logmax))))
		return;
		
	/* relocate buffer pointers */
	diff					= (ptr) - (ti->buffer);
	ti->publ.linemode		= (uint8_t*)((intptr_t)(ti->publ.linemode) + diff);
	ti->publ.line_dirty		= (bool*)((intptr_t)(ti->publ.line_dirty) + diff);
	ti->tabs				= (uint8_t*)((intptr_t)(ti->tabs) + diff);
	ti->publ.cells			= (uint16_t**)((intptr_t)(ti->publ.cells) + diff);
	ti->publ.log			= (uint16_t**)((intptr_t)(ti->publ.log) + diff);
	
	for (i = 0; i < ti->publ.rows; i++)
		ti->publ.cells[i]	= (uint16_t*)((intptr_t)(ti->publ.cells[i]) + diff);
	
	for (i = 0; i < ti->publ.logmax; i++)
		ti->publ.log[i]		= (uint16_t*)((intptr_t)(ti->publ.log[i]) + diff);
		
	/* set buffer properties */
	ti->bufsize	= reqsize;
	ti->buffer	= ptr;
}

void acate_to_string(Terminal* rt)
{
	TermInternal* ti = (TermInternal*)rt;	
	
	/* this isn't complete; lots of private variables are missing at this point */
	/* still - this function shouldn't be used anyway. It's likely to be removed later on */
	
	printf("Terminal (0x%x):\r\n", (unsigned int)ti);
	printf("{\r\n");
	printf("  publ.cols           : %d\r\n", (unsigned int)ti->publ.cols);
	printf("  publ.rows           : %d\r\n", (unsigned int)ti->publ.rows);
	printf("  publ.cells          : 0x%x\r\n", (unsigned int)ti->publ.cells);
	printf("  publ.linemode       : 0x%x\r\n", (unsigned int)ti->publ.linemode);
	printf("  publ.line_dirty     : 0x%x\r\n", (unsigned int)ti->publ.line_dirty);
	printf("  publ.log            : 0x%x\r\n", (unsigned int)ti->publ.log);
	printf("  publ.logmax         : %d\r\n", (unsigned int)ti->publ.logmax);
	printf("  publ.logpos         : %d\r\n", (unsigned int)ti->publ.logpos);
	printf("  publ.logsiz         : %d\r\n", (unsigned int)ti->publ.logsiz);
	printf("  publ.logchanged     : %d\r\n", (unsigned int)ti->publ.logchanged);
	printf("  publ.mousepos_dirty : %d\r\n", (unsigned int)ti->publ.mousepos_dirty);
	printf("  publ.mouse_mode     : %d\r\n", (unsigned int)ti->publ.mouse_mode);
	printf("  publ.mouse_col      : %d\r\n", (unsigned int)ti->publ.mouse_col);
	printf("  publ.mouse_row      : %d\r\n", (unsigned int)ti->publ.mouse_row);
	printf("  publ.curpos_dirty   : %d\r\n", (unsigned int)ti->publ.curpos_dirty);
	printf("  publ.curs_mode      : %d\r\n", (unsigned int)ti->publ.curs_mode);
	printf("  publ.col            : %d\r\n", (unsigned int)ti->publ.col);
	printf("  publ.row            : %d\r\n", (unsigned int)ti->publ.row);
	printf("  publ.callback_bell  : 0x%x\r\n", (unsigned int)ti->publ.callback_bell);
	printf("  publ.callback_osc   : 0x%x\r\n", (unsigned int)ti->publ.callback_osc);
	printf("  publ.callback_write : 0x%x\r\n", (unsigned int)ti->publ.callback_write);
	printf("  publ.parent_ref     : 0x%x\r\n", (unsigned int)ti->publ.parent_ref);
	printf("  bufsize             : %d\r\n", (unsigned int)ti->bufsize);
	printf("  buffer              : 0x%x\r\n", (unsigned int)ti->buffer);
	printf("}\r\n");
}