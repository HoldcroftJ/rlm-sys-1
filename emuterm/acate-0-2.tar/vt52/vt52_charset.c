static void vt52_charset(TermInternal* ti, uint8_t charset)
{
	switch(charset)
	{
		case 'F':
			prim_use_g1(ti);
			break;
		case 'G':
			prim_use_g0(ti);
			break;
	}
}