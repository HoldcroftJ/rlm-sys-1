static void vt52_ht(TermInternal* ti, uint8_t data)
{
	for(ti->publ.col++ ;
		(ti->publ.col < ti->publ.cols) && (!ti->tabs[ti->publ.col]);
		ti->publ.col++);	
}