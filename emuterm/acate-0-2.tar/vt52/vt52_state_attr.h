	/* 0x20... 0x7F */
	#undef	NEXT_STATE
	#undef	ACTION
	#define	NEXT_STATE	st_vt52_ground
	#define	ACTION		vt52_char_attr

	#include "state_block_32.h"		
	#include "state_block_32.h"	
	#include "state_block_32.h"	