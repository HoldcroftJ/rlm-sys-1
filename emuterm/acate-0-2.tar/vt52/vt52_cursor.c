static void vt52_curs_save(TermInternal *ti, uint8_t ignore)
{
	ti->saved_col = ti->publ.col;
	ti->saved_row = ti->publ.row;
}

static void vt52_curs_restore(TermInternal *ti, uint8_t ignore)
{
	ti->publ.col = ti->saved_col;
	ti->publ.row = ti->saved_row;
}

static void vt52_curs_index(TermInternal *ti, uint8_t ignore)
{	
	ti->publ.row++;		

	if(ti->publ.row >= ti->publ.rows)
	{
		prim_scroll_up(ti, 0, ti->publ.rows - 1);
		ti->publ.row = ti->publ.rows - 1;
	}
}

static void vt52_curs_index_rev(TermInternal *ti, uint8_t ignore)
{	
	ti->publ.row--;

	if(ti->publ.row  < 0)
	{
		prim_scroll_down(ti, 0, ti->publ.rows - 1);
		ti->publ.row = 0;
	}
}

static void vt52_curs_up(TermInternal *ti, uint8_t ignore)
{
	ti->publ.row--;
	
	if(ti->publ.row < 0)
		ti->publ.row = 0;
}

static void vt52_curs_down(TermInternal *ti, uint8_t ignore)
{
	ti->publ.row++;
	
	if(ti->publ.row >= ti->publ.rows)
		ti->publ.row = ti->publ.rows - 1;
}

static void vt52_curs_left(TermInternal *ti, uint8_t ignore)
{
	ti->publ.col--;
	
	if(ti->publ.col < 0)
		ti->publ.col = 0;}

static void vt52_curs_right(TermInternal *ti, uint8_t ignore)
{
	ti->publ.col++;
	
	if(ti->publ.col >= ti->publ.cols)
		ti->publ.row = ti->publ.cols - 1;
}

static void vt52_curs_tops(TermInternal *ti, uint8_t ignore)
{
	ti->publ.row = 0;
}

static void vt52_curs_home(TermInternal *ti, uint8_t ignore)
{
	ti->publ.row = 0;
	ti->publ.col = 0;
}

static void vt52_curs_place(TermInternal *ti, uint8_t data)
{	
	ti->publ.row = ti->collect_buffer[0] - ' ' - 1;
	ti->publ.col = data - ' ' - 1;

	if(ti->publ.col < 0)
		ti->publ.col = 0;
	else if(ti->publ.col >= ti->publ.cols)
		ti->publ.col = ti->publ.cols - 1;

	if(ti->publ.row < 0)
		ti->publ.row = 0;
	else if(ti->publ.row >= ti->publ.rows)
		ti->publ.row = ti->publ.rows - 1;
}