static void vt52_disp_erase(TermInternal *ti, uint8_t ignore)
{	
	prim_erase_disp(ti);
	ti->publ.col = 0;
	ti->publ.row = 0;
}

static void vt52_disp_erase_to(TermInternal *ti, uint8_t ignore)
{
	prim_erase_disp_tocursor(ti);
}

static void vt52_disp_erase_from(TermInternal *ti, uint8_t ignore)
{
	prim_erase_disp_fromcursor(ti);
}