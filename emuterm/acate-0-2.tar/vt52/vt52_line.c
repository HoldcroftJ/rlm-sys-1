static void vt52_line_delete(TermInternal *ti, uint8_t ignore)
{
	prim_scroll_up(ti, ti->publ.row, ti->publ.rows - 1);
}

static void vt52_line_insert(TermInternal *ti, uint8_t ignore)
{
	prim_scroll_down(ti, ti->publ.row, ti->publ.rows - 1);
}

static void vt52_line_erase(TermInternal *ti, uint8_t ignore)
{
	prim_erase_line(ti, ti->publ.row);
}

static void vt52_line_erase_from(TermInternal *ti, uint8_t ignore)
{
	prim_erase_line_fromcursor(ti);
}

static void vt52_line_erase_to(TermInternal *ti, uint8_t ignore)
{
	prim_erase_line_tocursor(ti);
}
