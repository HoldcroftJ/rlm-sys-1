static void vt52_char_delete(TermInternal *ti, uint8_t ignore)
{
	prim_delete(ti, ti->param_buffer[0]);
}

static void vt52_char_insert(TermInternal *ti, uint8_t ignore)
{
	prim_insert(ti, ti->param_buffer[0]);
}

static void vt52_char_erase(TermInternal *ti, uint8_t ignore)
{
	prim_erase(ti, ti->param_buffer[0]);
}

static void vt52_char_attr(TermInternal *ti, uint8_t data)
{
	switch(ti->collect_buffer[0])
	{
		case 'b':	/* fg color */
			ti->cur.fg = data & 0x0f;
			break;
		case 'c':	/* bg color */
			ti->cur.bg = data & 0x0f;
			break;
	}

	prim_compile_attr(ti);	
}

static void vt52_char_inv(TermInternal *ti, uint8_t data)
{
	ti->cur.reverse = data == 'p';
	
	prim_compile_attr(ti);
}

static void vt52_char_put(TermInternal *ti, uint8_t data)
{
	if (ti->publ.col >= ti->publ.cols)
	{
		ti->publ.col = 0;
		vt52_curs_index(ti,0);
	}
	
	if(ti->insert)
		prim_insert(ti, 1);
	
	prim_put(ti, data);

	ti->publ.col++;
}