static void vt52_bell(TermInternal* ti, uint8_t data);
static void vt52_bs(TermInternal* ti, uint8_t data);
static void vt52_lf(TermInternal* ti, uint8_t data);
static void vt52_cr(TermInternal* ti, uint8_t data);
static void vt52_crlf(TermInternal* ti, uint8_t data);
static void vt52_ht(TermInternal* ti, uint8_t data);

static void vt52_line_delete(TermInternal* ti, uint8_t ignore);
static void vt52_line_insert(TermInternal* ti, uint8_t ignore);
static void vt52_line_erase(TermInternal* ti, uint8_t ignore);
static void vt52_line_erase_to(TermInternal* ti, uint8_t ignore);
static void vt52_line_erase_from(TermInternal* ti, uint8_t ignore);

static void vt52_disp_erase(TermInternal* ti, uint8_t ignore);
static void vt52_disp_erase_to(TermInternal* ti, uint8_t ignore);
static void vt52_disp_erase_from(TermInternal* ti, uint8_t ignore);

static void vt52_curs_save(TermInternal* ti, uint8_t ignore);
static void vt52_curs_restore(TermInternal* ti, uint8_t ignore);

static void vt52_curs_index(TermInternal* ti, uint8_t ignore);
static void vt52_curs_index_rev(TermInternal* ti, uint8_t ignore);

static void vt52_curs_up(TermInternal* ti, uint8_t ignore);
static void vt52_curs_down(TermInternal* ti, uint8_t ignore);
static void vt52_curs_left(TermInternal* ti, uint8_t ignore);
static void vt52_curs_right(TermInternal* ti, uint8_t ignore);
static void vt52_curs_place(TermInternal* ti, uint8_t ignore);

static void vt52_curs_home(TermInternal* ti, uint8_t ignore);

static void vt52_char_delete(TermInternal* ti, uint8_t ignore);
static void vt52_char_insert(TermInternal* ti, uint8_t ignore);
static void vt52_char_erase(TermInternal* ti, uint8_t data);
static void vt52_char_attr(TermInternal* ti, uint8_t data);
static void vt52_char_inv(TermInternal* ti, uint8_t data);
static void vt52_char_put(TermInternal* ti, uint8_t data);

static void vt52_charset(TermInternal* ti, uint8_t charset);

static void vt52_unknown_esc(TermInternal* ti, uint8_t ignore);
static void vt52_esc_init(TermInternal* ti, uint8_t ignore);
static void vt52_id(TermInternal* ti, uint8_t ignore);
static void vt52_reset(TermInternal* ti, uint8_t ignore);
static void vt52_set_mode(TermInternal* ti, uint8_t ignore);

static void vt52_nop(TermInternal* ti, uint8_t ignore);

static void vt52_latch(TermInternal* ti, uint8_t data);

static void vt52_go_vt102(TermInternal* ti, uint8_t ignore);

#include "states_vt52.h"

#include "vt52_misc.c"
#include "vt52_control.c"
#include "vt52_charset.c"
#include "vt52_char.c"
#include "vt52_cursor.c"
#include "vt52_line.c"
#include "vt52_display.c"
#include "vt52_tab.c"
