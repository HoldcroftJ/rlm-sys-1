static void vt52_latch(TermInternal* ti, uint8_t data)
{
	ti->collect_buffer[0] = data;
	ti->param_position = 1;
}

static void vt52_nop(TermInternal* ti, uint8_t data)
{
}

static void vt52_unknown_esc(TermInternal* ti, uint8_t data)
{
//	printf("Unknown escape code detected: '%c'\n", data);
}

static void vt52_esc_init(TermInternal* ti, uint8_t data)
{
	ti->collect_buffer[0] = 0;
	ti->param_position = 0;
}

static void vt52_id(TermInternal* ti, uint8_t ignore)
{
	if(ti->param_buffer[0] == 0)
		acate_send((Terminal*)ti, "/Z", 0);	/* VT52 Identification*/
}

static void vt52_reset(TermInternal* ti, uint8_t ignore)
{
	ti->publ.curs_mode	= true;
	ti->wrap			= true;
	ti->cur.fg			= 7;
	ti->cur.bg			= 0;
	ti->publ.mouse_mode	= 0;
	prim_use_g0(ti);
}

static void vt52_set_mode(TermInternal* ti, uint8_t data)
{
	switch(data)
	{
		case 'e': ti->publ.curs_mode = true;	break;
		case 'f': ti->publ.curs_mode = false;	break;		
		case 'v': ti->wrap = true;		break;
		case 'w': ti->wrap = false;	break;	
	}
}

static void vt52_go_vt102(TermInternal* ti, uint8_t ignore)
{
	prim_go_vt102(ti);
}