/*
 LICENSE INFORMATION:
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License (LGPL) as published by the Free Software Foundation.
 
 Please refer to the COPYING file for more information.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 
 Copyright (c) 2010 Peter Persson (pep.fishmoose@gmail.com)
 */

#ifndef _vt52_state_DEFS_H_
#define _vt52_state_DEFS_H_

struct state_entry st_vt102_ground[];
struct state_entry st_vt52_ground[];
struct state_entry st_vt52_escape[];
struct state_entry st_vt52_row[];
struct state_entry st_vt52_col[];
struct state_entry st_vt52_attr[];

struct state_entry st_vt52_ground[256] =
{
	#undef	NEXT_STATE
	#define NEXT_STATE	st_vt52_ground
	#include "vt52_dispatch_ctrl.h"

	#include "vt52_state_ground.h"
	#include "state_block_32.h"
	#include "vt52_state_ground.h"
};

struct state_entry st_vt52_escape[256] =
{
	#undef	NEXT_STATE
	#define NEXT_STATE	st_vt52_escape
	#include "vt52_dispatch_ctrl.h"

	#include "vt52_dispatch_esc.h"
	#include "state_block_32.h"
	#include "vt52_dispatch_esc.h"
};

struct state_entry st_vt52_row[256] =
{
	#undef	NEXT_STATE
	#define NEXT_STATE	st_vt52_row
	#include "vt52_dispatch_ctrl.h"

	#include "vt52_state_row.h"
	#include "state_block_32.h"
	#include "vt52_state_row.h"
};

struct state_entry st_vt52_col[256] =
{
	#undef	NEXT_STATE
	#define NEXT_STATE	st_vt52_col
	#include "vt52_dispatch_ctrl.h"

	#include "vt52_state_col.h"
	#include "state_block_32.h"
	#include "vt52_state_col.h"
};

struct state_entry st_vt52_attr[256] =
{
	#undef	NEXT_STATE
	#define NEXT_STATE	st_vt52_attr
	#include "vt52_dispatch_ctrl.h"

	#include "vt52_state_attr.h"
	#include "state_block_32.h"
	#include "vt52_state_attr.h"
};
#endif