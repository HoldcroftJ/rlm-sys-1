	#undef	NEXT_STATE
	#undef	ACTION
	#define NEXT_STATE	st_vt52_ground
	#define	ACTION		vt52_nop

	/* 0x20... 0x2f */
	#include "state_block_16.h"
	
	/* 0x30... 0x37 */
	#include "state_block_8.h"

	/* 0x38... 0x3F */
	{st_vt52_ground, vt52_nop},			/* 8 */
	{st_vt52_ground, vt52_nop},			/* 9 */
	{st_vt52_ground, vt52_nop},			/* : */
	{st_vt52_ground, vt52_nop},			/* ; */
	{st_vt102_ground, vt52_go_vt102},	/* < */
	{st_vt52_ground, vt52_nop},			/* = */
	{st_vt52_ground, vt52_nop},			/* > */
	{st_vt52_ground, vt52_nop},			/* ? */

	/* 0x40... 0x4F */
	{st_vt52_ground, vt52_nop},			/* @ */
	{st_vt52_ground, vt52_curs_up},		/* A */
	{st_vt52_ground, vt52_curs_down},	/* B */
	{st_vt52_ground, vt52_curs_right},	/* C */
	
	{st_vt52_ground, vt52_curs_left},	/* D */
	{st_vt52_ground, vt52_disp_erase},	/* E */
	{st_vt52_ground, vt52_charset},		/* F */
	{st_vt52_ground, vt52_charset},		/* G */
	
	{st_vt52_ground, vt52_curs_home},	/* H */
	{st_vt52_ground, vt52_curs_index_rev},	/* I */
	{st_vt52_ground, vt52_disp_erase_from},	/* J */
	{st_vt52_ground, vt52_line_erase_from},	/* K */
	
	{st_vt52_ground, vt52_line_insert},	/* L */
	{st_vt52_ground, vt52_line_delete},	/* M */
	{st_vt52_ground, vt52_nop},			/* N */
	{st_vt52_ground, vt52_nop},			/* O */

	/* 0x50... 0x5F */
	{st_vt52_ground, vt52_nop},			/* P */
	{st_vt52_ground, vt52_nop},			/* Q */
	{st_vt52_ground, vt52_nop},			/* R */
	{st_vt52_ground, vt52_nop},			/* S */
	
	{st_vt52_ground, vt52_nop},			/* T */
	{st_vt52_ground, vt52_nop},			/* U */
	{st_vt52_ground, vt52_nop},			/* V */
	{st_vt52_ground, vt52_nop},			/* W */
	
	{st_vt52_ground, vt52_nop},			/* X */
	{st_vt52_row   , vt52_nop},			/* Y */
	{st_vt52_ground, vt52_id},		/* Z */
	{st_vt52_ground, vt52_nop},			/* [ */
	
	{st_vt52_ground, vt52_nop},			/* \ */
	{st_vt52_ground, vt52_nop},			/* ] */
	{st_vt52_ground, vt52_nop},			/* ^ */
	{st_vt52_ground, vt52_nop},			/* _ */

	/* 0x60... 0x6F */
	{st_vt52_ground, vt52_nop},			/* ` */
	{st_vt52_ground, vt52_nop},			/* a */
	{st_vt52_attr, vt52_latch},			/* b */
	{st_vt52_attr, vt52_latch},			/* c */
	
	{st_vt52_ground, vt52_nop},			/* d */
	{st_vt52_ground, vt52_set_mode},	/* e */
	{st_vt52_ground, vt52_set_mode},	/* f */
	{st_vt52_ground, vt52_nop},			/* g */
	
	{st_vt52_ground, vt52_nop},			/* h */
	{st_vt52_ground, vt52_nop},			/* i */
	{st_vt52_ground, vt52_nop},			/* j */
	{st_vt52_ground, vt52_nop},			/* k */
	
	{st_vt52_ground, vt52_nop},			/* l */
	{st_vt52_ground, vt52_nop},			/* m */
	{st_vt52_ground, vt52_nop},			/* n */
	{st_vt52_ground, vt52_nop},			/* o */
	
	/* 0x70... 0x7F */
	{st_vt52_ground, vt52_char_inv},	/* p */
	{st_vt52_ground, vt52_char_inv},	/* q */
	{st_vt52_ground, vt52_nop},			/* r */
	{st_vt52_ground, vt52_nop},			/* s */
	
	{st_vt52_ground, vt52_nop},			/* t */
	{st_vt52_ground, vt52_nop},			/* u */
	{st_vt52_ground, vt52_set_mode},	/* v */
	{st_vt52_ground, vt52_set_mode},	/* w */
	
	{st_vt52_ground, vt52_nop},			/* x */
	{st_vt52_ground, vt52_nop},			/* y */
	{st_vt52_ground, vt52_nop},			/* z */
	{st_vt52_ground, vt52_nop},			/* { */
	
	{st_vt52_ground, vt52_nop},			/* | */
	{st_vt52_ground, vt52_nop},			/* } */
	{st_vt52_ground, vt52_nop},			/* ~ */
	{st_vt52_ground, vt52_nop},			/* DEL */

