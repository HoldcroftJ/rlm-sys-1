	/* 0x00... 0x07*/
	{NEXT_STATE, vt52_nop}, {NEXT_STATE, vt52_nop},
	{NEXT_STATE, vt52_nop}, {NEXT_STATE, vt52_nop},
	{NEXT_STATE, vt52_nop}, {NEXT_STATE, vt52_nop},
	{NEXT_STATE, vt52_nop}, {NEXT_STATE, vt52_bell},

	/* 0x08... 0x0f*/
	{NEXT_STATE, vt52_bs},	{NEXT_STATE, vt52_ht},
	{NEXT_STATE, vt52_lf},	{NEXT_STATE, vt52_lf},
	{NEXT_STATE, vt52_lf}, {NEXT_STATE, vt52_cr},
	{NEXT_STATE, vt52_nop},{NEXT_STATE, vt52_nop},

	/* 0x10... 0x17*/
	{NEXT_STATE, vt52_nop}, {NEXT_STATE, vt52_nop},
	{NEXT_STATE, vt52_nop}, {NEXT_STATE, vt52_nop},
	{NEXT_STATE, vt52_nop}, {NEXT_STATE, vt52_nop},
	{NEXT_STATE, vt52_nop}, {NEXT_STATE, vt52_nop},

	/* 0x18... 0x1f*/
	{st_vt52_ground, vt52_nop}, {NEXT_STATE, vt52_nop},
	{st_vt52_ground, vt52_nop}, {st_vt52_escape, vt52_esc_init},
	
	{NEXT_STATE, vt52_nop}, {NEXT_STATE, vt52_nop},
	{NEXT_STATE, vt52_nop}, {NEXT_STATE, vt52_nop},
