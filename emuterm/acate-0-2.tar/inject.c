/*
 LICENSE INFORMATION:
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License (LGPL) as published by the Free Software Foundation.
 
 Please refer to the COPYING file for more information.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 
 Copyright (c) 2010 Peter Persson (pep.fishmoose@gmail.com)
 */

#include "private.h"

static inline void prim_go_vt52(TermInternal* ti)
{
	if(ti->vt52 == false)
	{
		ti->vt52	= true;
		/* the actual state change is performed in the state table */
	}
}

static inline void prim_go_vt102(TermInternal* ti)
{
	if(ti->vt52 == true)
	{
		ti->vt52	= false;
		/* the actual state change is performed in the state table */
	}
}

static inline void prim_set_g_cur(TermInternal* ti, uint16_t charset)
{
	ti->cur.charset_g[ti->cur.current_g] = ti->char_lookup[charset];
}

static inline void prim_set_g0(TermInternal* ti, uint16_t charset)
{
	ti->cur.charset_g[0] = ti->char_lookup[charset];
}

static inline void prim_set_g1(TermInternal* ti, uint16_t charset)
{
	ti->cur.charset_g[1] = ti->char_lookup[charset];
}

static inline void prim_use_g0(TermInternal* ti)
{
	ti->cur.current_g = 0;
}

static inline void prim_use_g1(TermInternal* ti)
{
	ti->cur.current_g = 1;
}

static inline void prim_bell(TermInternal* ti)
{
	if(ti->publ.callback_bell)
		ti->publ.callback_bell(ti->publ.parent_ref);
}

static inline void prim_osc_init(TermInternal* ti)
{
	ti->osc_buffer[0] = 0;
	ti->osc_position = 0;
}

static inline void prim_osc_put(TermInternal* ti, uint8_t data)
{
	if(ti->osc_position < (BUF_SIZE - 1))
	{
		ti->osc_buffer[ti->osc_position++] = data;
		ti->osc_buffer[ti->osc_position] = 0;
	}
}

static inline void prim_osc_send(TermInternal* ti, uint8_t data)
{
	if(ti->publ.callback_osc)
		ti->publ.callback_osc(ti->publ.parent_ref, ti->osc_buffer);
}

static inline void prim_compile_attr(TermInternal* ti)
{
	ti->cur.attr = (ti->cur.fg << 4) | ti->cur.bg;
	
	if(ti->cur.full || ti->cur.italics)
		ti->cur.attr |= 0x80;
	
	if(ti->cur.half)
		ti->cur.attr &= 0x7f;
		
	if(ti->cur.underline || ti->cur.blink)
		ti->cur.attr |= 0x08;
		
	if(ti->cur.reverse)
		ti->cur.attr = (ti->cur.attr << 4) | (ti->cur.attr >> 4);
		
	ti->cur.attr <<= 8;
}

static inline void prim_erase_line(TermInternal* ti, uint16_t line)
{
	uint16_t i;
	
	for (i = 0; i < ti->publ.cols; i++)
		ti->publ.cells[line][i] = ti->cur.attr | ' ';
		
	ti->publ.line_dirty[line]		= true;
}

static inline void prim_erase_line_tocursor(TermInternal* ti)
{
	uint16_t i;
	
	for (i = 0; i <= ti->publ.col; i++)
		ti->publ.cells[ti->publ.row][i] = ti->cur.attr | ' ';

	ti->publ.line_dirty[ti->publ.row] = true;
}

static inline void prim_erase_line_fromcursor(TermInternal* ti)
{
	uint16_t i;
	
	for (i = ti->publ.col; i < ti->publ.cols; i++)
		ti->publ.cells[ti->publ.row][i] = ti->cur.attr | ' ';	

	ti->publ.line_dirty[ti->publ.row] = true;
}

static inline void prim_erase_disp(TermInternal* ti)
{
	uint16_t i;
	
	for(i = 0; i < ti->publ.rows; i++)
		prim_erase_line(ti, i);
}

static inline void prim_erase_disp_tocursor(TermInternal* ti)
{
	uint16_t i;
	
	prim_erase_line_tocursor(ti);

	for(i = 0; i < ti->publ.row; i++)
		prim_erase_line(ti, i);
}

static inline void prim_erase_disp_fromcursor(TermInternal* ti)
{
	uint16_t i;
	
	prim_erase_line_fromcursor(ti);
		
	for(i = ti->publ.row + 1; i < ti->publ.rows; i++)
		prim_erase_line(ti, i);
}

static inline void prim_insert(TermInternal* ti, uint16_t nr)
{
	uint16_t i;
	
	if(!nr)
		nr++;

	for (i = ti->publ.cols - 1; i >= ti->publ.col + nr; i--)
		ti->publ.cells[ti->publ.row][i] = ti->publ.cells[ti->publ.row][i - nr];
		
	for (i = ti->publ.col; i < ti->publ.col + nr; i++)
		ti->publ.cells[ti->publ.row][i] = ti->cur.attr | ' ';	

	ti->publ.line_dirty[ti->publ.row] = true;
}

static inline void prim_delete(TermInternal* ti, uint16_t nr)
{
	uint16_t i;
	
	if(!nr)
		nr++;
		
	for (i = ti->publ.col; i < ti->publ.cols; i++)
	{
		if ((i + nr) < ti->publ.cols)
			ti->publ.cells[ti->publ.row][i] = ti->publ.cells[ti->publ.row][i + nr];
		else
			ti->publ.cells[ti->publ.row][i] = ti->cur.attr | ' ';	
	}

	ti->publ.line_dirty[ti->publ.row] = true;
}

static inline void prim_erase(TermInternal* ti, uint16_t nr)
{
	uint16_t i;
	
	for (i = ti->publ.col; (i < ti->publ.col) + nr && (i < ti->publ.cols); i++)
		ti->publ.cells[ti->publ.row][i] = ti->cur.attr | ' ';	

	ti->publ.line_dirty[ti->publ.row] = true;
}

static inline void prim_put(TermInternal* ti, uint8_t c)
{
	ti->publ.cells[ti->publ.row][ti->publ.col] = ti->cur.attr | ti->cur.charset_g[ti->cur.current_g][c];	

	ti->publ.line_dirty[ti->publ.row] = true;
}

static inline void prim_scroll_up(TermInternal* ti, uint16_t start, uint16_t stop)
{
	uint16_t* c;

	ti->publ.logchanged = true;
	
	c = ti->publ.log[ti->publ.logpos];
	ti->publ.log[ti->publ.logpos] = ti->publ.cells[start];
	ti->publ.logpos = ++ti->publ.logpos % ti->publ.logmax;
	
	if(ti->publ.logsiz < ti->publ.logmax)
		ti->publ.logsiz++;
	
	for(; start < stop; start++)
	{
		ti->publ.cells[start] = ti->publ.cells[start + 1];
		ti->publ.linemode[start] = ti->publ.linemode[start + 1];
		ti->publ.line_dirty[start] = true;
	}

	ti->publ.cells[stop] = c;
	prim_erase_line(ti, stop);
}

static inline void prim_scroll_down(TermInternal* ti, uint16_t start, uint16_t stop)
{
	uint16_t* c;

	c = ti->publ.cells[stop];

	for(; stop > start; stop--)
	{
		ti->publ.cells[stop] = ti->publ.cells[stop - 1];
		ti->publ.linemode[start] = ti->publ.linemode[start - 1];
		ti->publ.line_dirty[stop] = true;
	}

	ti->publ.cells[start] = c;
	prim_erase_line(ti, start);
}

#include "vt52.c"
#include "vt102.c"

void acate_inject(Terminal *rt, uint8_t *data, size_t len)
{
	TermInternal*	ti		= (TermInternal*)rt;
	STATE_ENTRY*	state	= ti->state;

	if(!len)
		len = strlen(data);
	
	while(len--)
	{	
		state[*data].action(ti, *data);		
		state = state[*data++].next;
	}

	ti->state = state;
}