/*
 LICENSE INFORMATION:
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License (LGPL) as published by the Free Software Foundation.
 
 Please refer to the COPYING file for more information.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 
 Copyright (c) 2010 Peter Persson (pep.fishmoose@gmail.com)
 */

#include "private.h"

static uint8_t* keys_func[32][4] = /* normal, shifted, alt, control */
{
	{ "\033[[A",	"\033[23~",	"",		"\033[[A"	},	/* F1  */
	{ "\033[[B",	"\033[24~",	"",		"\033[[B"	},	/* F2  */	
	{ "\033[[C",	"\033[25~",	"",		"\033[[C"	},	/* F3  */	
	{ "\033[[D",	"\033[26~",	"",		"\033[[D"	},	/* F4  */	
	{ "\033[[E",	"\033[28~",	"",		"\033[[E"	},	/* F5  */	
	{ "\033[17~",	"\033[29~",	"",		"\033[17~"	},	/* F6  */	
	{ "\033[18~",	"\033[31~",	"",		"\033[18~"	},	/* F7  */	
	{ "\033[19~",	"\033[32~",	"",		"\033[19~"	},	/* F8  */	
	{ "\033[20~",	"\033[33~",	"",		"\033[20~"	},	/* F9  */	
	{ "\033[21~",	"\033[34~",	"",		"\033[21~"	},	/* F10 */
	{ "\033[23~",	"",		"",		"\033[23~"	},	/* F11 */
	{ "\033[24~",	"",		"",		"\033[24~"	},	/* F12 */
	{ "\033[25~",	"",		"",		"\033[25~"	},	/* F13 */	
	{ "\033[26~",	"",		"",		"\033[26~"	},	/* F14 */	
	{ "\033[28~",	"",		"",		"\033[28~"	},	/* F15 */	
	{ "\033[29~",	"",		"",		"\033[29~"	},	/* F16 */	
	{ "\033[31~",	"",		"",		"\033[31~"	},	/* F17 */	
	{ "\033[32~",	"",		"",		"\033[32~"	},	/* F18 */	
	{ "\033[33~",	"",		"",		"\033[33~"	},	/* F19 */	
	{ "\033[34~",	"",		"",		"\033[34~"	},	/* F20  */	
	{ "",		"",		"",		""		},	/* F21  */
	{ "",		"",		"",		""		},	/* F22  */
	{ "",		"",		"",		""		},	/* F23  */
	{ "",		"",		"",		""		},	/* F24  */
	{ "",		"",		"",		""		},	/* F25  */
	{ "",		"",		"",		""		},	/* F26  */
	{ "",		"",		"",		""		},	/* F27  */
	{ "",		"",		"",		""		},	/* F28  */
	{ "",		"",		"",		""		},	/* F29  */
	{ "",		"",		"",		""		},	/* F30  */
	{ "",		"",		"",		""		},	/* F31  */
	{ "",		"",		"",		""		}	/* F32  */
};

static uint8_t* keys_cursor[4][4] = /* normal, shifted, alt, control */
{
	{ "\033[A",	"\033[5~",	"",		""		},	/* UP */
	{ "\033[B",	"\033[6~",	"",		""		},	/* DOWN */
	{ "\033[C",	"",		"",		""		},	/* RIGHT */
	{ "\033[D",	"",		"",		""		}	/* LEFT */
};

static uint8_t* keys_spec[8][4] = /* normal, shifted, alt, control */
{
	{ "\177",	"\010",		"",		""		},	/* DELETE */
	{ "\033[2~",	"",		"",		""		},	/* INSERT */
	{ "\033[1~",	"\033[1~",	"\033[1~",	"\033[1~"	},	/* HOME */
	{ "\033[5~",	"",		"",		""		},	/* PAGE UP */
	{ "\033[6~",	"",		"",		""		},	/* PAGE DOWN */
	{ "",		"",		"",		""		},	/*  */
	{ "",		"",		"",		""		},	/*  */
	{ "",		"",		"",		""		}	/*  */
};

static uint8_t* keys_keypad[16][4] = /* normal, shifted, alt, control */
{
	{ "0",		"0",		"0",		""		},	/* 0 */
	{ "1",		"1",		"1",		""		},	/* 1 */
	{ "2",		"2",		"2",		""		},	/* 2 */
	{ "3",		"3",		"3",		""		},	/* 3 */
	{ "4",		"4",		"4",		""		},	/* 4 */
	{ "5",		"5",		"5",		""		},	/* 5 */
	{ "6",		"6",		"6",		""		},	/* 6 */
	{ "7",		"7",		"7",		""		},	/* 7 */
	{ "8",		"8",		"8",		""		},	/* 8 */
	{ "9",		"9",		"9",		""		},	/* 9 */
	{ "*",		"*",		"*",		""		},	/* mult */
	{ "+",		"+",		"+",		""		},	/* add */
	{ "-",		"-",		"-",		""		},	/* sub */
	{ "/",		"/",		"/",		""		},	/* div */
	{ ".",		".",		".",		""		},	/* dec */
	{ "\r",		"\r",		"\r",		""		}	/* enter */
};


void acate_key(Terminal* rt, uint16_t keycode, uint16_t mode)
{
	switch(keycode & 0xff00)
	{
		case AC_CURSOR_KEYS:	acate_send(rt, keys_cursor[keycode & 0x03][mode], 0);	break;
		case AC_FUNCTION_KEYS:	acate_send(rt, keys_func[keycode & 0x1f][mode], 0);		break;
		case AC_SPECIAL_KEYS:	acate_send(rt, keys_spec[keycode & 0x07][mode], 0);		break;
		case AC_KEYPAD_KEYS:	acate_send(rt, keys_keypad[keycode & 0x0f][mode], 0);	break;
			
		case AC_NORMAL_KEYS:
		{
			static uint8_t	buf[40];
			uint8_t*		ptr = buf;
			
			if(mode == 2)
				*ptr++ = 27;

			*ptr++ = keycode & 0xff;
			*ptr++ = 0;
			
			acate_send(rt, buf, 0);
		}
			break;
		default:
			break;
	}
}

void acate_mouse(Terminal* rt, uint16_t buttons, uint16_t x, uint16_t y)
{
	static uint8_t buf[] = { 27, '[', 'M', ' ', '!', '!', 0 };
	
	buf[3] = ' ';
	buf[4] = '!' + x;
	buf[5] = '!' + y;
	
	switch(rt->mouse_mode)
	{
		case 0:		return;

		case 1:		/* X10 mouse report */
				if((buttons & 0x03) != 3)
					buf[3] += buttons & 0x03;
				else
					return;

		case 2:		/* VT200 mouse report */
				buf[3] = ' ' + buttons;
			break;
	}
	
	acate_send(rt, buf, 0);
}